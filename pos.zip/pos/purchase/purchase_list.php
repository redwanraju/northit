<?php
session_start();
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(false);


if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
error_reporting(E_ALL);
ini_set('display_errors',1);

include "../../config/db.php";
$shop_id = tenantShopId();


// ============================================================
// HELPER FUNCTIONS
// ============================================================

function tableExists($conn, $table) {
    static $cache = [];
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($table === '') return false;
    if (isset($cache[$table])) return $cache[$table];

    $stmt = $conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1");
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_row() : [0];
    $cache[$table] = ((int)($row[0] ?? 0) > 0);
    return $cache[$table];
}

function columnExists($conn, $table, $column) {
    static $cache = [];
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $column = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    if ($table === '' || $column === '') return false;

    $key = $table . '.' . $column;
    if (isset($cache[$key])) return $cache[$key];

    $stmt = $conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
    $stmt->bind_param("ss", $table, $column);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_row() : [0];
    $cache[$key] = ((int)($row[0] ?? 0) > 0);
    return $cache[$key];
}

function rvAssetLabel($assetType) {
    $labels = [
        'cash' => 'Cash In Hand',
        'bkash' => 'bKash',
        'nagad' => 'Nagad',
        'bank' => 'Bank',
        'other' => 'Other'
    ];
    return $labels[$assetType] ?? ucfirst((string)$assetType);
}

// ============================================================
// CSRF TOKEN
// ============================================================
if (empty($_SESSION['rv_dashboard_csrf'])) {
    $_SESSION['rv_dashboard_csrf'] = bin2hex(random_bytes(32));
}

function normalizePaymentAssetType($paymentMethod) {
    $method = strtolower(trim((string)$paymentMethod));

    if (strpos($method, 'bkash') !== false || strpos($method, 'b-kash') !== false || strpos($method, 'বিকাশ') !== false) {
        return 'bkash';
    }
    if (strpos($method, 'nagad') !== false || strpos($method, 'nagod') !== false || strpos($method, 'নগদ') !== false) {
        return 'nagad';
    }
    if (strpos($method, 'bank') !== false || strpos($method, 'card') !== false || strpos($method, 'cheque') !== false) {
        return 'bank';
    }
    if (strpos($method, 'cash') !== false || strpos($method, 'hand') !== false) {
        return 'cash';
    }

    return 'other';
}

function refundPurchaseAsset($conn, $shop_id, $asset_id, $amount) {
    $asset_id = (int)$asset_id;
    $amount = (float)$amount;

    if ($asset_id <= 0 || $amount <= 0) return;

    $stmt = $conn->prepare("SELECT id, amount FROM assets WHERE id = ? AND shop_id = ? LIMIT 1 FOR UPDATE");
    $stmt->bind_param("ii", $asset_id, $shop_id);
    $stmt->execute();
    $asset = $stmt->get_result()->fetch_assoc();

    if (!$asset) {
        throw new Exception('Original payment asset was not found for refund. Asset ID: ' . $asset_id);
    }

    $stmt = $conn->prepare("UPDATE assets SET amount = amount + ? WHERE id = ? AND shop_id = ?");
    $stmt->bind_param("dii", $amount, $asset_id, $shop_id);
    $stmt->execute();

    if ($stmt->affected_rows !== 1) {
        throw new Exception('Failed to refund purchase payment to asset ID: ' . $asset_id);
    }
}

function refundPurchaseFallbackAsset($conn, $shop_id, $asset_type, $amount) {
    $asset_type = normalizePaymentAssetType($asset_type);
    $amount = (float)$amount;

    if ($amount <= 0) return 0;

    $stmt = $conn->prepare("
        SELECT id
        FROM assets
        WHERE shop_id = ? AND asset_type = ?
        ORDER BY (status = 'active') DESC, id ASC
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->bind_param("is", $shop_id, $asset_type);
    $stmt->execute();
    $asset = $stmt->get_result()->fetch_assoc();

    if (!$asset) {
        return 0;
    }

    refundPurchaseAsset($conn, $shop_id, (int)$asset['id'], $amount);
    return (int)$asset['id'];
}

// ============================================================
// DELETE PURCHASE + COMPLETE REVERSAL
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_purchase_id'])) {
    $delete_id = (int)($_POST['delete_purchase_id'] ?? 0);
    $invoice_image_to_delete = '';

    try {
        if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['rv_dashboard_csrf'] ?? '', $_POST['csrf_token'])) {
            throw new Exception('Invalid security token. Please reload the page.');
        }
        if ($delete_id <= 0) {
            throw new Exception('Invalid Purchase ID.');
        }

        $conn->begin_transaction();

        // Lock and verify purchase belongs to current shop.
        $stmt = $conn->prepare("
            SELECT p.*, s.shop_id AS supplier_shop_id
            FROM purchases p
            INNER JOIN suppliers s ON s.id = p.supplier_id
            WHERE p.id = ? AND s.shop_id = ?
            LIMIT 1
            FOR UPDATE
        ");
        $stmt->bind_param("ii", $delete_id, $shop_id);
        $stmt->execute();
        $purchase = $stmt->get_result()->fetch_assoc();

        if (!$purchase) {
            throw new Exception('Purchase not found.');
        }

        $supplier_id = (int)$purchase['supplier_id'];
        $grand_total = (float)($purchase['grand_total'] ?? 0);
        $paid_amount = (float)($purchase['paid_amount'] ?? 0);
        $current_due = max(0, $grand_total - $paid_amount);
        $invoice_no = trim((string)($purchase['invoice_no'] ?? ''));
        $invoice_label = $invoice_no !== '' ? $invoice_no : ('Purchase #' . $delete_id);
        $invoice_image_to_delete = trim((string)($purchase['invoice_image'] ?? ''));

        // 1) Reverse purchased stock.
        $stmt = $conn->prepare("
            SELECT product_id, quantity
            FROM purchase_items
            WHERE purchase_id = ? AND shop_id = ?
            FOR UPDATE
        ");
        $stmt->bind_param("ii", $delete_id, $shop_id);
        $stmt->execute();
        $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        if (empty($items)) {
            throw new Exception('No purchase items found. Delete cancelled to protect stock data.');
        }

        $updateStock = $conn->prepare("
            UPDATE products
            SET stock = COALESCE(stock, 0) - ?
            WHERE id = ? AND shop_id = ?
        ");

        $insertMovement = null;
        if (tableExists($conn, 'stock_movements')) {
            $insertMovement = $conn->prepare("
                INSERT INTO stock_movements (product_id, type, qty, note)
                VALUES (?, 'out', ?, ?)
            ");
        }

        foreach ($items as $item) {
            $product_id = (int)$item['product_id'];
            $qty = (float)$item['quantity'];
            if ($product_id <= 0 || $qty <= 0) continue;

            $updateStock->bind_param("dii", $qty, $product_id, $shop_id);
            $updateStock->execute();

            if ($updateStock->affected_rows !== 1) {
                throw new Exception('Product not found while reversing stock. Product ID: ' . $product_id);
            }

            if ($insertMovement) {
                $note = 'Purchase delete reversal: ' . $invoice_label;
                $insertMovement->bind_param("ids", $product_id, $qty, $note);
                $insertMovement->execute();
            }
        }

        // 2) Refund every purchase-linked asset transaction to its original asset.
        $asset_refund_total = 0.0;
        $asset_tx_by_type = [];

        if (tableExists($conn, 'asset_transactions') && tableExists($conn, 'assets')) {
            $stmt = $conn->prepare("
                SELECT from_asset_id,
                       COALESCE(from_asset_type, 'other') AS from_asset_type,
                       SUM(amount) AS refund_amount
                FROM asset_transactions
                WHERE shop_id = ?
                  AND reference_type = 'purchase'
                  AND reference_id = ?
                  AND transaction_type = 'out'
                  AND from_asset_id IS NOT NULL
                GROUP BY from_asset_id, from_asset_type
            ");
            $stmt->bind_param("ii", $shop_id, $delete_id);
            $stmt->execute();
            $asset_transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            foreach ($asset_transactions as $asset_tx) {
                $asset_id = (int)$asset_tx['from_asset_id'];
                $refund_amount = (float)$asset_tx['refund_amount'];
                if ($asset_id <= 0 || $refund_amount <= 0) continue;

                refundPurchaseAsset($conn, $shop_id, $asset_id, $refund_amount);
                $asset_refund_total += $refund_amount;

                $type = normalizePaymentAssetType($asset_tx['from_asset_type']);
                $asset_tx_by_type[$type] = ($asset_tx_by_type[$type] ?? 0) + $refund_amount;
            }
        }

        // 3) Legacy fallback: refund purchase payments that have no asset transaction row.
        $payment_by_type = [];
        if (tableExists($conn, 'supplier_payments')) {
            $stmt = $conn->prepare("
                SELECT payment_method, SUM(payment_amount) AS total_amount
                FROM supplier_payments
                WHERE purchase_id = ? AND supplier_id = ?
                GROUP BY payment_method
            ");
            $stmt->bind_param("ii", $delete_id, $supplier_id);
            $stmt->execute();
            $payment_rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            foreach ($payment_rows as $payment_row) {
                $type = normalizePaymentAssetType($payment_row['payment_method']);
                $payment_by_type[$type] = ($payment_by_type[$type] ?? 0) + (float)$payment_row['total_amount'];
            }
        }

        foreach ($payment_by_type as $type => $payment_total) {
            $already_refunded_for_type = (float)($asset_tx_by_type[$type] ?? 0);
            $missing_refund = $payment_total - $already_refunded_for_type;

            if ($missing_refund > 0.009) {
                if (!tableExists($conn, 'assets')) {
                    throw new Exception('Assets table not found. Purchase payment cannot be reversed safely.');
                }
                $fallback_asset_id = refundPurchaseFallbackAsset($conn, $shop_id, $type, $missing_refund);
                if ($fallback_asset_id > 0) {
                    $asset_refund_total += $missing_refund;
                }
            }
        }

        // Legacy purchases may have paid_amount but no asset/payment ledger record.
        // In that case no asset is guessed, preventing a false balance increase.
        $unmatched_paid_amount = max(0, $paid_amount - $asset_refund_total);

        // 4) Remove current outstanding due from supplier balance.
        if ($current_due > 0 && columnExists($conn, 'suppliers', 'current_due')) {
            $stmt = $conn->prepare("
                UPDATE suppliers
                SET current_due = COALESCE(current_due, 0) - ?
                WHERE id = ? AND shop_id = ?
            ");
            $stmt->bind_param("dii", $current_due, $supplier_id, $shop_id);
            $stmt->execute();

            if ($stmt->affected_rows !== 1) {
                throw new Exception('Supplier due reversal failed.');
            }
        }

        // 5) Delete linked ledger rows and purchase records.
        if (tableExists($conn, 'asset_transactions')) {
            $stmt = $conn->prepare("
                DELETE FROM asset_transactions
                WHERE shop_id = ? AND reference_type = 'purchase' AND reference_id = ?
            ");
            $stmt->bind_param("ii", $shop_id, $delete_id);
            $stmt->execute();
        }

        if (tableExists($conn, 'supplier_payments')) {
            $stmt = $conn->prepare("
                DELETE FROM supplier_payments
                WHERE purchase_id = ? AND supplier_id = ?
            ");
            $stmt->bind_param("ii", $delete_id, $supplier_id);
            $stmt->execute();
        }

        $stmt = $conn->prepare("DELETE FROM purchase_items WHERE purchase_id = ? AND shop_id = ?");
        $stmt->bind_param("ii", $delete_id, $shop_id);
        $stmt->execute();

        $stmt = $conn->prepare("
            DELETE p
            FROM purchases p
            INNER JOIN suppliers s ON s.id = p.supplier_id
            WHERE p.id = ? AND s.shop_id = ?
        ");
        $stmt->bind_param("ii", $delete_id, $shop_id);
        $stmt->execute();

        if ($stmt->affected_rows !== 1) {
            throw new Exception('Purchase delete failed. No data was changed.');
        }

        $conn->commit();

        // Delete invoice image only after database commit succeeds.
        if ($invoice_image_to_delete !== '') {
            $image_path = '../../uploads/invoices/' . basename($invoice_image_to_delete);
            if (is_file($image_path)) {
                @unlink($image_path);
            }
        }

        $success_message = 'Purchase deleted. Stock and supplier due were reversed.';
        if ($asset_refund_total > 0) {
            $success_message .= ' ৳' . number_format($asset_refund_total, 2) . ' was refunded to the original asset(s).';
        }
        if ($unmatched_paid_amount > 0.01) {
            $success_message .= ' Legacy paid amount ৳' . number_format($unmatched_paid_amount, 2) . ' had no linked asset record, so no asset was guessed.';
        }

        $_SESSION['rv_dashboard_flash'] = [
            'type' => 'success',
            'message' => $success_message
        ];

    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $ignore) {}
        $_SESSION['rv_dashboard_flash'] = ['type' => 'error', 'message' => $e->getMessage()];
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// ============================================================
// PAYMENT POST HANDLER
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['purchase_id'])) {
    try {
        if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['rv_dashboard_csrf'] ?? '', $_POST['csrf_token'])) {
            throw new Exception('Invalid security token. Please reload the page.');
        }

        $purchase_id = (int)($_POST['purchase_id'] ?? 0);
        $asset_id = (int)($_POST['asset_id'] ?? 0);
        $paid_amount = (float)($_POST['paid_amount'] ?? 0);
        $payment_date = $_POST['payment_date'] ?? date('Y-m-d');
        $note = trim($_POST['note'] ?? '');

        if ($purchase_id <= 0) throw new Exception('Purchase ID required.');
        if ($asset_id <= 0) throw new Exception('Please select payment asset.');
        if ($paid_amount <= 0) throw new Exception('Paid amount must be greater than 0.');

        $conn->begin_transaction();

        $stmt = $conn->prepare("SELECT p.id, p.supplier_id, p.grand_total, p.paid_amount FROM purchases p INNER JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ? AND s.shop_id = ? FOR UPDATE");
        $stmt->bind_param("ii", $purchase_id, $shop_id);
        $stmt->execute();
        $purchase = $stmt->get_result()->fetch_assoc();
        if (!$purchase) throw new Exception('Purchase not found.');

        $current_due = $purchase['grand_total'] - $purchase['paid_amount'];
        if ($current_due <= 0) throw new Exception('This purchase has no due amount.');
        if ($paid_amount > $current_due) throw new Exception('Paid amount cannot exceed due amount.');

        $stmt = $conn->prepare("SELECT id, asset_type, asset_name, amount FROM assets WHERE id = ? AND shop_id = ? AND status = 'active' FOR UPDATE");
        $stmt->bind_param("ii", $asset_id, $shop_id);
        $stmt->execute();
        $asset = $stmt->get_result()->fetch_assoc();
        if (!$asset) throw new Exception('Selected asset not found or inactive.');

        $asset_before = (float)$asset['amount'];
        if ($paid_amount > $asset_before) throw new Exception('Insufficient balance in selected asset.');
        $asset_after = $asset_before - $paid_amount;

        $new_paid = (float)$purchase['paid_amount'] + $paid_amount;
        $new_due = max(0, (float)$purchase['grand_total'] - $new_paid);

        $stmt = $conn->prepare("UPDATE purchases p INNER JOIN suppliers s ON s.id = p.supplier_id SET p.paid_amount = ?, p.due_amount = ? WHERE p.id = ? AND s.shop_id = ?");
        $stmt->bind_param("ddii", $new_paid, $new_due, $purchase_id, $shop_id);
        $stmt->execute();

        $stmt = $conn->prepare("UPDATE assets SET amount = ? WHERE id = ? AND shop_id = ?");
        $stmt->bind_param("dii", $asset_after, $asset_id, $shop_id);
        $stmt->execute();

        if (tableExists($conn, 'supplier_payments')) {
            $payment_method = rvAssetLabel($asset['asset_type']);
            $payment_datetime = $payment_date . ' ' . date('H:i:s');
            $stmt = $conn->prepare("INSERT INTO supplier_payments (supplier_id, purchase_id, payment_amount, payment_method, note, payment_date) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iidsss", $purchase['supplier_id'], $purchase_id, $paid_amount, $payment_method, $note, $payment_datetime);
            $stmt->execute();
        }

        if (tableExists($conn, 'asset_transactions')) {
            $sql = "INSERT INTO asset_transactions 
                (shop_id, transaction_type, movement_type, from_asset_id, from_asset_type, from_asset_name, amount, from_balance_before, from_balance_after, reference_type, reference_id, transaction_date, note) 
                VALUES (?, 'out', 'supplier_payment', ?, ?, ?, ?, ?, ?, 'purchase', ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iissdddiss", 
                $shop_id,               
                $asset_id,              
                $asset['asset_type'],   
                $asset['asset_name'],   
                $paid_amount,           
                $asset_before,          
                $asset_after,           
                $purchase_id,           
                $payment_date,          
                $note                   
            );
            $stmt->execute();
        }

        if (tableExists($conn, 'suppliers') && columnExists($conn, 'suppliers', 'current_due')) {
            $stmt = $conn->prepare("UPDATE suppliers SET current_due = current_due - ? WHERE id = ? AND shop_id = ?");
            $stmt->bind_param("dii", $paid_amount, $purchase['supplier_id'], $shop_id);
            $stmt->execute();
        }

        $conn->commit();
        
        $_SESSION['rv_dashboard_flash'] = ['type' => 'success', 'message' => 'Payment of ৳ ' . number_format($paid_amount, 2) . ' saved successfully.'];
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['rv_dashboard_flash'] = ['type' => 'error', 'message' => $e->getMessage()];
    }
    
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// ============================================================
// FLASH MESSAGE DISPLAY
// ============================================================
$flash_message = '';
if (!empty($_SESSION['rv_dashboard_flash'])) {
    $flash_message = $_SESSION['rv_dashboard_flash'];
    unset($_SESSION['rv_dashboard_flash']);
}

/* ================= FILTER ================= */

$where = " WHERE s.shop_id = " . (int)$shop_id . " ";

if(isset($_GET['supplier_id']) && $_GET['supplier_id']!=""){
    $supplier_id=(int)$_GET['supplier_id'];
    $where .= " AND p.supplier_id=".$supplier_id;
}

if(isset($_GET['invoice']) && trim($_GET['invoice'])!=""){
    $invoice=$conn->real_escape_string($_GET['invoice']);
    $where .= " AND p.invoice_no LIKE '%$invoice%'";
}

if(isset($_GET['from']) && $_GET['from']!=""){
    $from=$conn->real_escape_string($_GET['from']);
    $where .= " AND DATE(p.created_at)>='$from'";
}

if(isset($_GET['to']) && $_GET['to']!=""){
    $to=$conn->real_escape_string($_GET['to']);
    $where .= " AND DATE(p.created_at)<='$to'";
}


/* ================= SUMMARY ================= */

$summary = $conn->query("
SELECT
COUNT(p.id) total_purchase,
IFNULL(SUM(p.grand_total),0) total_amount,
IFNULL(SUM(p.paid_amount),0) total_paid,
IFNULL(SUM(p.grand_total - p.paid_amount),0) total_due
FROM purchases p
INNER JOIN suppliers s ON s.id = p.supplier_id
$where
")->fetch_assoc();



/* ================= LIST ================= */

$purchases = $conn->query("
SELECT 
p.*,
s.supplier_name
FROM purchases p
INNER JOIN suppliers s ON s.id=p.supplier_id
$where
ORDER BY p.id DESC
");



$suppliers = $conn->query("
SELECT id,supplier_name 
FROM suppliers
WHERE shop_id = $shop_id
ORDER BY supplier_name
");


// ============================================================
// GET ASSET BALANCES
// ============================================================

$rv_payment_assets = [];

if (tableExists($conn, 'assets') && columnExists($conn, 'assets', 'shop_id')) {
    $asset_query = $conn->query("
        SELECT id, asset_type, asset_name, amount 
        FROM assets 
        WHERE shop_id = $shop_id AND status = 'active' 
        AND asset_type IN ('cash','bkash','nagad','bank','other')
        ORDER BY FIELD(asset_type,'cash','bkash','nagad','bank','other'), asset_name ASC
    ");
    
    if ($asset_query && $asset_query->num_rows > 0) {
        while ($asset = $asset_query->fetch_assoc()) {
            $rv_payment_assets[] = $asset;
        }
    }
}

if (empty($rv_payment_assets)) {
    $rv_payment_assets = [
        ['id' => 0, 'asset_type' => 'cash', 'asset_name' => 'Cash In Hand', 'amount' => 0],
        ['id' => 0, 'asset_type' => 'bkash', 'asset_name' => 'bKash', 'amount' => 0],
        ['id' => 0, 'asset_type' => 'nagad', 'asset_name' => 'Nagad', 'amount' => 0],
        ['id' => 0, 'asset_type' => 'bank', 'asset_name' => 'Bank', 'amount' => 0],
    ];
}

include "../header.php";
include "../sidebar.php";
?>


<style>
/* ===== MAIN LAYOUT FIX ===== */
.main {
    padding: 20px;
    background: #f8fafc;
    min-height: 100vh;
    width: 100%;
    flex: 1;
}

/* Card Styles */
.card-box {
    background: #fff;
    padding: 20px;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(0,0,0,.06);
    margin-bottom: 20px;
    width: 100%;
}

.stat-card {
    padding: 20px;
    border-radius: 15px;
    color: #fff;
    height: 100%;
}

.bg-blue{background:#2563eb;}
.bg-green{background:#16a34a;}
.bg-red{background:#dc2626;}
.bg-dark{background:#0f172a;}
.bg-purple{background:#7c3aed;}

.stat-title{
    font-size:14px;
    opacity:.9;
}

.stat-value{
    font-size:26px;
    font-weight:700;
}

/* Table Styles */
.table thead th {
    background: #0f172a;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    padding: 10px 8px;
}

.table td {
    vertical-align: middle;
    padding: 8px 6px;
}

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.btn {
    border-radius: 8px;
    font-size: 13px;
}

.badge-paid {
    background: #dcfce7;
    color: #166534;
    padding: 5px 10px;
    border-radius: 20px;
    font-weight: 600;
}

.badge-due {
    background: #fee2e2;
    color: #991b1b;
    padding: 5px 10px;
    border-radius: 20px;
    font-weight: 600;
}

.action-btns .btn {
    padding: 4px 10px;
    margin: 2px;
    font-size: 13px;
}

.action-btns .btn i {
    font-size: 13px;
}

/* Flash Message */
.rv-flash {
    padding: 12px 18px;
    border-radius: 8px;
    margin-bottom: 16px;
    font-weight: 700;
}
.rv-flash-success {
    background: #dcfce7;
    color: #166534;
    border-left: 4px solid #22c55e;
}
.rv-flash-error {
    background: #fee2e2;
    color: #991b1b;
    border-left: 4px solid #ef4444;
}

/* ===== Payment Modal ===== */
.rv-pay-overlay {
    position: fixed;
    inset: 0;
    z-index: 99999;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(2, 6, 23, 0.55);
}
.rv-pay-overlay.rv-pay-show {
    display: flex;
}
.rv-pay-card {
    width: min(600px, 96vw);
    background: #ffffff;
    border-radius: 6px;
    box-shadow: 0 24px 72px rgba(0,0,0,0.36);
    overflow: hidden;
    font-family: 'Segoe UI', system-ui, sans-serif;
}
.rv-pay-head {
    height: 48px;
    padding: 0 20px;
    background: #27983a;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
}
.rv-pay-title {
    font-size: 1.2rem;
    font-weight: 900;
}
.rv-pay-close {
    border: 0;
    background: transparent;
    color: #fff;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    padding: 4px;
}
.rv-pay-close:hover {
    opacity: 0.8;
}
.rv-pay-body {
    padding: 16px 12px 8px;
}
.rv-pay-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}
.rv-pay-group {
    margin-bottom: 10px;
}
.rv-pay-group.rv-full {
    grid-column: 1 / -1;
}
.rv-pay-label {
    display: block;
    margin-bottom: 5px;
    font-size: 0.9rem;
    line-height: 1.1;
    color: #27272a;
    font-weight: 800;
}
.rv-pay-input, .rv-pay-select, .rv-pay-textarea {
    width: 100%;
    border: 1px solid #cfd6dc;
    border-radius: 4px;
    background: #ffffff;
    padding: 8px 14px;
    font-size: 0.95rem;
    color: #3f3f46;
    outline: none;
}
.rv-pay-input, .rv-pay-select {
    height: 43px;
}
.rv-pay-textarea {
    min-height: 60px;
    resize: vertical;
}
.rv-pay-input:focus, .rv-pay-select:focus, .rv-pay-textarea:focus {
    border-color: #22c55e;
    box-shadow: 0 0 0 3px rgba(34,197,94,0.12);
}
.rv-pay-input[readonly] {
    background: #e9ecef;
}
.rv-pay-hint {
    display: block;
    margin-top: 5px;
    color: #64748b;
    font-size: 0.75rem;
    font-weight: 700;
}
.rv-pay-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
    padding: 10px 12px 14px;
}
.rv-pay-btn {
    border: 0;
    border-radius: 999px;
    padding: 8px 28px;
    font-size: 0.95rem;
    font-weight: 800;
    color: #fff;
    cursor: pointer;
    min-width: 100px;
}
.rv-pay-save {
    background: #22a538;
}
.rv-pay-save:hover {
    background: #1a8a2e;
}
.rv-pay-cancel {
    background: #94a3b8;
}
.rv-pay-cancel:hover {
    background: #64748b;
}
.asset-balance-warning {
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #991b1b;
    padding: 8px 12px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 700;
    margin-top: 8px;
    display: none;
}
.asset-balance-warning.show {
    display: block;
}

/* ===== View Modal ===== */
.rv-view-overlay {
    position: fixed;
    inset: 0;
    z-index: 99998;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(2, 6, 23, 0.55);
}
.rv-view-overlay.rv-view-show {
    display: flex;
}
.rv-view-card {
    width: min(700px, 96vw);
    max-height: 90vh;
    overflow-y: auto;
    background: #ffffff;
    border-radius: 6px;
    box-shadow: 0 24px 72px rgba(0,0,0,0.36);
    font-family: 'Segoe UI', system-ui, sans-serif;
}
.rv-view-head {
    padding: 15px 20px;
    background: #2563eb;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    position: sticky;
    top: 0;
    z-index: 10;
}
.rv-view-title {
    font-size: 1.2rem;
    font-weight: 900;
}
.rv-view-close {
    border: 0;
    background: transparent;
    color: #fff;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    padding: 4px;
}
.rv-view-body {
    padding: 20px;
}
.rv-view-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
    margin-bottom: 12px;
}
.rv-view-group {
    padding: 8px 0;
    border-bottom: 1px solid #e5e7eb;
}
.rv-view-label {
    font-size: 0.8rem;
    color: #6b7280;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.rv-view-value {
    font-size: 1rem;
    font-weight: 600;
    color: #1f2937;
    margin-top: 2px;
}

@media (max-width: 768px) {
    .main {
        padding: 12px;
    }
    .rv-pay-row, .rv-view-row {
        grid-template-columns: 1fr;
    }
    .stat-value {
        font-size: 20px;
    }
    .stat-card {
        padding: 15px;
    }
    .action-btns .btn {
        padding: 3px 8px;
        font-size: 12px;
    }
    .action-btns .btn i {
        font-size: 12px;
    }
    .table td, .table th {
        padding: 6px 4px;
        font-size: 13px;
    }
    .card-box {
        padding: 12px;
    }
}

@media (min-width: 1200px) {
    .container-fluid, .row {
        width: 100%;
        margin: 0;
    }
}
</style>


<div class="main">

<!-- Flash Message -->
<?php if (!empty($flash_message)): ?>
    <div class="rv-flash rv-flash-<?= $flash_message['type'] ?>">
        <?= htmlspecialchars($flash_message['message']) ?>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h3 class="m-0">📦 Purchase List</h3>
    <a href="add_purchase.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> New Purchase
    </a>
</div>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="stat-card bg-blue">
            <div class="stat-title">Total Purchase</div>
            <div class="stat-value"><?= $summary['total_purchase'] ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="stat-card bg-dark">
            <div class="stat-title">Purchase Amount</div>
            <div class="stat-value">৳ <?= number_format($summary['total_amount'],2) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="stat-card bg-green">
            <div class="stat-title">Paid</div>
            <div class="stat-value">৳ <?= number_format($summary['total_paid'],2) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="stat-card bg-red">
            <div class="stat-title">Due</div>
            <div class="stat-value">৳ <?= number_format($summary['total_due'],2) ?></div>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="card-box">
    <form method="GET" class="row g-2 align-items-end">
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label fw-bold mb-1">Supplier</label>
            <select name="supplier_id" class="form-control form-control-sm">
                <option value="">All Supplier</option>
                <?php 
                $suppliers->data_seek(0);
                while($s = $suppliers->fetch_assoc()){ ?>
                    <option value="<?= $s['id'] ?>" <?= isset($_GET['supplier_id']) && $_GET['supplier_id'] == $s['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['supplier_name']) ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="col-12 col-sm-6 col-md-2">
            <label class="form-label fw-bold mb-1">Invoice</label>
            <input type="text" name="invoice" class="form-control form-control-sm" placeholder="Invoice No" value="<?= isset($_GET['invoice']) ? htmlspecialchars($_GET['invoice']) : '' ?>">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label fw-bold mb-1">From</label>
            <input type="date" name="from" class="form-control form-control-sm" value="<?= isset($_GET['from']) ? htmlspecialchars($_GET['from']) : '' ?>">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label fw-bold mb-1">To</label>
            <input type="date" name="to" class="form-control form-control-sm" value="<?= isset($_GET['to']) ? htmlspecialchars($_GET['to']) : '' ?>">
        </div>
        <div class="col-12 col-md-3">
            <button class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
            <a href="purchase_list.php" class="btn btn-secondary btn-sm">Reset</a>
        </div>
    </form>
</div>

<!-- Table -->
<div class="card-box">
    <div class="table-responsive">
        <table class="table table-bordered table-hover mb-0">
            <thead>
                <tr>
                    <th style="width:45px;">#</th>
                    <th style="min-width:100px;">Invoice</th>
                    <th style="min-width:100px;">Date</th>
                    <th style="min-width:120px;">Supplier</th>
                    <th style="min-width:90px;">Total</th>
                    <th style="min-width:90px;">Paid</th>
                    <th style="min-width:90px;">Due</th>
                    <th style="min-width:70px;">Status</th>
                    <th style="min-width:200px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i=1;
                if ($purchases && $purchases->num_rows > 0):
                while($p = $purchases->fetch_assoc()){
                    $due = $p['grand_total'] - $p['paid_amount'];
                    $status = $due <= 0 ? 
                        '<span class="badge-paid">Paid</span>' :
                        '<span class="badge-due">Due</span>';
                ?>
                    <tr>
                        <td class="text-center"><?= $i++ ?></td>
                        <td><strong><?= htmlspecialchars($p['invoice_no'] ?: 'N/A') ?></strong></td>
                        <td><?= date('d-m-Y',strtotime($p['created_at'])) ?></td>
                        <td><?= htmlspecialchars($p['supplier_name'] ?? 'Unknown') ?></td>
                        <td class="text-end">৳ <?= number_format($p['grand_total'],2) ?></td>
                        <td class="text-end">৳ <?= number_format($p['paid_amount'],2) ?></td>
                        <td class="text-end">৳ <?= number_format($due,2) ?></td>
                        <td class="text-center"><?= $status ?></td>
                        <td>
                            <div class="action-btns d-flex flex-wrap justify-content-center gap-1">
                                <button type="button" class="btn btn-sm btn-info" onclick="viewPurchase(<?= $p['id'] ?>)">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <a href="edit_purchase.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-warning text-white">
                                    <i class="fas fa-edit"></i>
                                </a>
								<!--
                                <button type="button" class="btn btn-sm btn-success" onclick="openPaymentModal(<?= $p['id'] ?>, '<?= htmlspecialchars($p['invoice_no'] ?: 'N/A') ?>', <?= $due ?>)">
                                    <i class="fas fa-money-bill"></i>
                                </button>
								-->
                                <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="d-inline" onsubmit="return confirmPurchaseDelete();">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['rv_dashboard_csrf'] ?? '') ?>">
                                    <input type="hidden" name="delete_purchase_id" value="<?= (int)$p['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete and reverse purchase">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php } 
                else: ?>
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <i class="fas fa-inbox fa-2x d-block text-muted mb-2"></i>
                            No purchases found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</div>

<!-- ============= VIEW MODAL ============= -->
<div class="rv-view-overlay" id="viewModal" aria-hidden="true">
    <div class="rv-view-card">
        <div class="rv-view-head">
            <div class="rv-view-title"><i class="fas fa-receipt"></i> Purchase Details</div>
            <button type="button" class="rv-view-close" onclick="closeViewModal()">&times;</button>
        </div>
        <div class="rv-view-body" id="viewModalBody">
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============= PAYMENT MODAL ============= -->
<div class="rv-pay-overlay" id="paymentModal" aria-hidden="true">
    <div class="rv-pay-card">
        <div class="rv-pay-head">
            <div class="rv-pay-title">Purchase Payment</div>
            <button type="button" class="rv-pay-close" onclick="closePaymentModal()">&times;</button>
        </div>

        <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
            <input type="hidden" name="purchase_id" id="paymentPurchaseId">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['rv_dashboard_csrf'] ?? '' ?>">

            <div class="rv-pay-body">
                <div class="rv-pay-row">
                    <div class="rv-pay-group">
                        <label class="rv-pay-label">Invoice</label>
                        <input id="paymentInvoice" class="rv-pay-input" readonly>
                    </div>
                    <div class="rv-pay-group">
                        <label class="rv-pay-label">Due Amount</label>
                        <input id="paymentDueAmount" class="rv-pay-input" readonly>
                    </div>
                </div>

                <div class="rv-pay-row">
                    <div class="rv-pay-group">
                        <label class="rv-pay-label">Paid Amount *</label>
                        <input type="number" step="0.01" min="0.01" name="paid_amount" id="paymentAmount" class="rv-pay-input" required>
                        <small class="rv-pay-hint" id="amountHint"></small>
                    </div>
                    <div class="rv-pay-group">
                        <label class="rv-pay-label">Date</label>
                        <input type="date" name="payment_date" class="rv-pay-input" value="<?= date('Y-m-d') ?>">
                    </div>
                </div>

                <div class="rv-pay-group rv-full">
                    <label class="rv-pay-label">Payment *</label>
                    <select name="asset_id" id="paymentAsset" class="rv-pay-select" required>
                        <?php foreach($rv_payment_assets as $asset): ?>
                        <?php $isCash = ($asset['asset_type'] === 'cash'); ?>
                        <option value="<?= $asset['id'] ?>" 
                            data-balance="<?= (float)$asset['amount'] ?>"
                            <?= $isCash ? 'selected' : '' ?>>
                            <?= htmlspecialchars($isCash ? 'Cash In Hand' : (rvAssetLabel($asset['asset_type']) . ' - ' . ($asset['asset_name'] ?: ucfirst($asset['asset_type'])))) ?>
                            (<?= number_format($asset['amount'],2) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="rv-pay-group rv-full">
                    <label class="rv-pay-label">Note</label>
                    <textarea name="note" class="rv-pay-textarea"></textarea>
                    <div class="asset-balance-warning" id="balanceWarning">⚠️ Insufficient balance. Available: ৳ <span id="availableBalance">0.00</span></div>
                </div>
            </div>

            <div class="rv-pay-actions">
                <button type="button" onclick="closePaymentModal()" class="rv-pay-btn rv-pay-cancel">Cancel</button>
                <button type="submit" class="rv-pay-btn rv-pay-save">Save Payment</button>
            </div>
        </form>
    </div>
</div>


<?php include "../footer.php"; ?>

<script>
function confirmPurchaseDelete() {
    if (!confirm('⚠️ এই Purchase Delete করলে purchased stock কমবে, supplier due reverse হবে এবং paid টাকা original asset-এ ফেরত যাবে। চালিয়ে যাবেন?')) {
        return false;
    }
    return confirm('এই Purchase স্থায়ীভাবে মুছে যাবে। আপনি কি নিশ্চিত?');
}

// ============================================================
// VIEW PURCHASE MODAL
// ============================================================
function viewPurchase(purchaseId) {
    const modal = document.getElementById('viewModal');
    const body = document.getElementById('viewModalBody');
    
    body.innerHTML = `
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    modal.classList.add('rv-view-show');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('rv-modal-open');
    
    fetch(`purchase_view_ajax.php?id=${purchaseId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                let html = `
                    <div class="rv-view-row">
                        <div class="rv-view-group">
                            <div class="rv-view-label">Invoice No</div>
                            <div class="rv-view-value">${data.invoice_no || 'N/A'}</div>
                        </div>
                        <div class="rv-view-group">
                            <div class="rv-view-label">Date</div>
                            <div class="rv-view-value">${data.date || 'N/A'}</div>
                        </div>
                    </div>
                    <div class="rv-view-row">
                        <div class="rv-view-group">
                            <div class="rv-view-label">Supplier</div>
                            <div class="rv-view-value">${data.supplier_name || 'Unknown'}</div>
                        </div>
                        <div class="rv-view-group">
                            <div class="rv-view-label">Status</div>
                            <div class="rv-view-value">${data.status || 'N/A'}</div>
                        </div>
                    </div>
                    <div class="rv-view-row">
                        <div class="rv-view-group">
                            <div class="rv-view-label">Grand Total</div>
                            <div class="rv-view-value">৳ ${data.grand_total || '0.00'}</div>
                        </div>
                        <div class="rv-view-group">
                            <div class="rv-view-label">Paid Amount</div>
                            <div class="rv-view-value">৳ ${data.paid_amount || '0.00'}</div>
                        </div>
                    </div>
                    <div class="rv-view-row">
                        <div class="rv-view-group">
                            <div class="rv-view-label">Due Amount</div>
                            <div class="rv-view-value" style="color:${data.due > 0 ? '#dc2626' : '#16a34a'}">৳ ${data.due || '0.00'}</div>
                        </div>
                        <div class="rv-view-group">
                            <div class="rv-view-label">Items Count</div>
                            <div class="rv-view-value">${data.items_count || 0}</div>
                        </div>
                    </div>
                `;
                
                if (data.items && data.items.length > 0) {
                    html += `
                        <div class="mt-3">
                            <h6 class="fw-bold">Purchase Items</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>#</th>
                                            <th>Product</th>
                                            <th>Qty</th>
                                            <th>Unit</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    `;
                                    data.items.forEach((item, index) => {
                                        html += `
                                            <tr>
                                                <td>${index + 1}</td>
                                                <td>${item.product_name || 'Unknown'}</td>
                                                <td>${item.quantity || 0}</td>
                                                <td>${item.unit || '-'}</td>
                                                <td>৳ ${item.purchase_price || 0}</td>
                                                <td>৳ ${item.total || 0}</td>
                                            </tr>
                                        `;
                                    });
                    html += `
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    `;
                }
                
                body.innerHTML = html;
            } else {
                body.innerHTML = `
                    <div class="alert alert-danger">${data.message || 'Failed to load purchase details.'}</div>
                `;
            }
        })
        .catch(error => {
            body.innerHTML = `
                <div class="alert alert-danger">Error loading purchase details. Please try again.</div>
            `;
            console.error('Error:', error);
        });
}

function closeViewModal() {
    document.getElementById('viewModal').classList.remove('rv-view-show');
    document.getElementById('viewModal').setAttribute('aria-hidden', 'true');
    document.body.classList.remove('rv-modal-open');
}

document.getElementById('viewModal').addEventListener('click', function(event) {
    if (event.target === this) {
        closeViewModal();
    }
});

// ============================================================
// PAYMENT MODAL FUNCTIONS
// ============================================================

const assetBalances = {};
document.querySelectorAll('#paymentAsset option').forEach(option => {
    if (option.value) {
        assetBalances[option.value] = parseFloat(option.getAttribute('data-balance') || 0);
    }
});

function openPaymentModal(purchaseId, invoiceNo, dueAmount) {
    document.getElementById('paymentPurchaseId').value = purchaseId;
    document.getElementById('paymentInvoice').value = invoiceNo;
    document.getElementById('paymentDueAmount').value = '৳ ' + parseFloat(dueAmount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    document.getElementById('paymentAmount').value = '';
    document.getElementById('paymentAmount').max = dueAmount;
    document.getElementById('amountHint').textContent = 'Max: ৳ ' + parseFloat(dueAmount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    
    document.getElementById('balanceWarning').classList.remove('show');
    
    const cashOption = [...document.getElementById('paymentAsset').options]
        .find(option => option.textContent.includes('Cash In Hand'));
    if (cashOption) {
        document.getElementById('paymentAsset').value = cashOption.value;
    }
    
    document.getElementById('paymentModal').classList.add('rv-pay-show');
    document.getElementById('paymentModal').setAttribute('aria-hidden', 'false');
    document.body.classList.add('rv-modal-open');
    
    setTimeout(function() {
        document.getElementById('paymentAmount').focus();
    }, 100);
}

function closePaymentModal() {
    document.getElementById('paymentModal').classList.remove('rv-pay-show');
    document.getElementById('paymentModal').setAttribute('aria-hidden', 'true');
    document.body.classList.remove('rv-modal-open');
}

document.getElementById('paymentModal').addEventListener('click', function(event) {
    if (event.target === this) {
        closePaymentModal();
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        var modal = document.getElementById('paymentModal');
        if (modal.classList.contains('rv-pay-show')) {
            closePaymentModal();
        }
        var viewModal = document.getElementById('viewModal');
        if (viewModal.classList.contains('rv-view-show')) {
            closeViewModal();
        }
    }
});

document.getElementById('paymentAsset').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const balance = parseFloat(selectedOption.getAttribute('data-balance') || 0);
    const amount = parseFloat(document.getElementById('paymentAmount').value) || 0;
    const warning = document.getElementById('balanceWarning');
    const availableSpan = document.getElementById('availableBalance');
    
    if (amount > 0 && amount > balance) {
        availableSpan.textContent = balance.toFixed(2);
        warning.classList.add('show');
    } else {
        warning.classList.remove('show');
    }
});

document.getElementById('paymentAmount').addEventListener('input', function() {
    const amount = parseFloat(this.value) || 0;
    const method = document.getElementById('paymentAsset');
    const selectedOption = method.options[method.selectedIndex];
    const balance = parseFloat(selectedOption.getAttribute('data-balance') || 0);
    const warning = document.getElementById('balanceWarning');
    const availableSpan = document.getElementById('availableBalance');
    const dueAmount = parseFloat(this.max) || 0;
    
    document.getElementById('amountHint').textContent = 'Max: ৳ ' + dueAmount.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    
    if (method.value && amount > 0 && amount > balance) {
        availableSpan.textContent = balance.toFixed(2);
        warning.classList.add('show');
    } else {
        warning.classList.remove('show');
    }
});

document.querySelector('#paymentModal form').addEventListener('submit', function(event) {
    const amount = parseFloat(document.getElementById('paymentAmount').value);
    const dueAmount = parseFloat(document.getElementById('paymentAmount').max);
    const method = document.getElementById('paymentAsset');
    const selectedOption = method.options[method.selectedIndex];
    const balance = parseFloat(selectedOption.getAttribute('data-balance') || 0);
    
    if (!method.value) {
        event.preventDefault();
        alert('Please select a payment asset.');
        return false;
    }
    
    if (amount <= 0) {
        event.preventDefault();
        alert('Please enter a valid payment amount.');
        return false;
    }
    
    if (amount > dueAmount) {
        event.preventDefault();
        alert('Payment amount cannot exceed due amount (৳ ' + dueAmount.toFixed(2) + ').');
        return false;
    }
    
    if (amount > balance) {
        event.preventDefault();
        alert('Insufficient balance in selected payment asset! Available: ৳ ' + balance.toFixed(2));
        return false;
    }
    
    return true;
});
</script>