<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/session.php';
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(false);
$shop_id = tenantShopId();


if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');

include "../../config/db.php";
include "../header.php";
include "../sidebar.php";

/* ================= CSRF PROTECTION ================= */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

$csrf_token = generateCSRFToken();

/* ================= IMAGE UPLOAD FUNCTION ================= */
function uploadInvoiceImage($file) {
    $uploadDir = "../../uploads/invoices/";
    
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $fileName = time() . "_" . preg_replace('/[^a-zA-Z0-9._-]/', '', basename($file['name']));
    $targetPath = $uploadDir . $fileName;
    
    $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    $maxSize = 2 * 1024 * 1024;
    
    if (!in_array($file['type'], $allowedTypes)) {
        return ['error' => 'Only JPG, PNG, WEBP images allowed'];
    }
    
    if ($file['size'] > $maxSize) {
        return ['error' => 'Image must be less than 2MB'];
    }
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'file_name' => $fileName];
    }
    
    return ['error' => 'Upload failed'];
}

/* ================= SANITIZATION ================= */
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/* ================= SAVE PURCHASE ================= */
if(isset($_POST['save_purchase'])){
    // CSRF Verification
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        die("CSRF token validation failed.");
    }
    
    $supplier_id = filter_var($_POST['supplier_id'], FILTER_VALIDATE_INT);
    $invoice_no  = sanitize($_POST['invoice_no']);
    $subtotal    = filter_var($_POST['subtotal'], FILTER_VALIDATE_FLOAT);
    $delivery_charge = filter_var($_POST['delivery_charge'], FILTER_VALIDATE_FLOAT);
    $grand_total = $subtotal + $delivery_charge;
    $paid_amount = filter_var($_POST['paid_amount'], FILTER_VALIDATE_FLOAT);
    $payment_method = isset($_POST['payment_method']) ? sanitize($_POST['payment_method']) : 'cash';
    $due_amount = $grand_total - $paid_amount;

    // Validation
    if (!$supplier_id || $supplier_id <= 0) {
        die("Invalid supplier selected.");
    }
    if ($subtotal <= 0) {
        die("Subtotal must be greater than 0.");
    }
    if ($delivery_charge < 0) {
        die("Delivery charge cannot be negative.");
    }
    if ($paid_amount < 0) {
        die("Paid amount cannot be negative.");
    }
    if ($paid_amount > $grand_total) {
        die("Paid amount cannot exceed grand total.");
    }

    $supplierCheck = $conn->prepare("SELECT id FROM suppliers WHERE id = ? AND shop_id = ? AND status = 1 LIMIT 1");
    $supplierCheck->bind_param("ii", $supplier_id, $shop_id);
    $supplierCheck->execute();
    if (!$supplierCheck->get_result()->fetch_assoc()) {
        die("Invalid supplier selected for this shop.");
    }

    // Normalize invoice number
    $invoice_no = strtoupper($invoice_no);

    // Duplicate supplier invoice check
    if($supplier_id > 0 && !empty($invoice_no)){
        $checkInvoice = $conn->prepare("
            SELECT id FROM purchases 
            WHERE supplier_id=? AND invoice_no=?
            LIMIT 1
        ");
        $checkInvoice->bind_param("is", $supplier_id, $invoice_no);
        $checkInvoice->execute();
        $checkResult = $checkInvoice->get_result();

        if($checkResult->num_rows > 0){
            echo "<script>
            alert('Duplicate Invoice! Same supplier invoice already exists.');
            history.back();
            </script>";
            exit;
        }
    }
    
    $invoice_image = null;
    if (!empty($_FILES['invoice_image']['name'])) {
        $uploadResult = uploadInvoiceImage($_FILES['invoice_image']);
        if (isset($uploadResult['error'])) {
            echo "<script>alert('".addslashes($uploadResult['error'])."'); history.back();</script>";
            exit;
        }
        $invoice_image = $uploadResult['file_name'];
    }

    if($supplier_id > 0 && $grand_total > 0){
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO purchases (supplier_id, invoice_no, grand_total, delivery_charge, paid_amount, due_amount, invoice_image) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("isdddds", $supplier_id, $invoice_no, $grand_total, $delivery_charge, $paid_amount, $due_amount, $invoice_image);
            $stmt->execute();
            $purchase_id = $conn->insert_id;

            $itemStmt = $conn->prepare("INSERT INTO purchase_items (purchase_id, shop_id, product_id, category_id, brand_id, product_name, sku, barcode, purchase_price, sale_price, quantity, unit, total) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $updateProduct = $conn->prepare("UPDATE products SET 
purchase_price = ?, 
sale_price = ?, 
stock = stock + ? 
WHERE id = ? AND shop_id = ?");

            if(isset($_POST['product_id']) && is_array($_POST['product_id'])){
                foreach($_POST['product_id'] as $i => $product_id){
                    $product_id = filter_var($product_id, FILTER_VALIDATE_INT);
                    if(!$product_id || $product_id <= 0) continue;

                    $item_qty = filter_var($_POST['qty'][$i], FILTER_VALIDATE_FLOAT);
                    if(!$item_qty || $item_qty <= 0){ throw new Exception('Invalid quantity'); }
                    
                    $item_purchase_price = filter_var($_POST['purchase_price'][$i], FILTER_VALIDATE_FLOAT);
                    if(!$item_purchase_price || $item_purchase_price <= 0){ throw new Exception('Invalid purchase price'); }
                    
                    $item_sale_price = filter_var($_POST['sale_price'][$i], FILTER_VALIDATE_FLOAT);
                    if(!$item_sale_price || $item_sale_price <= 0){ throw new Exception('Invalid sale price'); }
                    
                    $item_total = $item_qty * $item_purchase_price;

                    $productStmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND shop_id = ? LIMIT 1");
                    $productStmt->bind_param("ii", $product_id, $shop_id);
                    $productStmt->execute();
                    $productData = $productStmt->get_result()->fetch_assoc();
                    if(!$productData) continue;

                    $item_shop_id      = $shop_id;
                    $item_category_id  = $productData['category_id'];
                    $item_brand_id     = $productData['brand_id'];
                    $item_product_name = $productData['product_name'];
                    $item_sku          = $productData['sku'];
                    $item_barcode      = $productData['barcode'];
                    $item_unit         = $productData['unit'];

                    $itemStmt->bind_param("iiiiisssdddsd", $purchase_id, $item_shop_id, $product_id, $item_category_id, $item_brand_id, $item_product_name, $item_sku, $item_barcode, $item_purchase_price, $item_sale_price, $item_qty, $item_unit, $item_total);
                    if(!$itemStmt->execute()){ throw new Exception("Purchase Item Insert Error: ".$itemStmt->error); }

                    $updateProduct->bind_param("dddii", $item_purchase_price, $item_sale_price, $item_qty, $product_id, $shop_id);
                    $updateProduct->execute();
                }
            }

            $stmt2 = $conn->prepare("UPDATE suppliers SET current_due = current_due + ? WHERE id=? AND shop_id=?");
            $stmt2->bind_param("dii", $due_amount, $supplier_id, $shop_id);
            $stmt2->execute();

            // ===== ASSET TRANSACTION FOR PAID AMOUNT =====
            if($paid_amount > 0){
                $assetTypeMap = [
                    'cash' => 'cash',
                    'bank' => 'bank',
                    'bkash' => 'bkash',
                    'nagad' => 'nagad'
                ];
                
                $assetType = isset($assetTypeMap[$payment_method]) ? $assetTypeMap[$payment_method] : 'cash';
                
                $assetQuery = $conn->prepare("SELECT id, amount, asset_name FROM assets WHERE shop_id=? AND asset_type=? AND status='active' ORDER BY id LIMIT 1");
                $assetQuery->bind_param("is", $shop_id, $assetType);
                $assetQuery->execute();
                $assetResult = $assetQuery->get_result();
                $asset = $assetResult->fetch_assoc();
                
                if($asset) {
                    $asset_id = $asset['id'];
                    $balance_before = $asset['amount'];
                    $balance_after = $balance_before - $paid_amount;
                    $asset_name = $asset['asset_name'];
                    $note_text = 'Purchase payment - ' . $invoice_no;
                    $user_id = $_SESSION['user_id'];
                    $txn_date = date('Y-m-d');
                    
                    $txnStmt = $conn->prepare("
                        INSERT INTO asset_transactions 
                        (shop_id, transaction_type, movement_type, from_asset_id, from_asset_type, from_asset_name, 
                         amount, from_balance_before, from_balance_after, reference_type, reference_id, 
                         transaction_date, note, created_by) 
                        VALUES 
                        (?, 'out', 'purchase_payment', ?, ?, ?, 
                         ?, ?, ?, 'purchase', ?, 
                         ?, ?, ?)
                    ");
                    
                    $txnStmt->bind_param(
                        "iissdddissi",
                        $shop_id,
                        $asset_id,
                        $assetType,
                        $asset_name,
                        $paid_amount,
                        $balance_before,
                        $balance_after,
                        $purchase_id,
                        $txn_date,
                        $note_text,
                        $user_id
                    );
                    $txnStmt->execute();
                    
                    $updateAsset = $conn->prepare("UPDATE assets SET amount = amount - ? WHERE id = ? AND shop_id = ?");
                    $updateAsset->bind_param("dii", $paid_amount, $asset_id, $shop_id);
                    $updateAsset->execute();
                }
            }

            $conn->commit();

            // The purchase form submits to a named new tab. After save, that tab
            // becomes the printable invoice while the original entry page is reset.
            $invoice_url = 'purchase_invoice.php?id=' . $purchase_id . '&saved=1';
            echo "<script>
                if (window.opener && !window.opener.closed) {
                    try { window.opener.location.replace('add_purchase.php?saved=1'); } catch (e) {}
                }
                window.location.replace(" . json_encode($invoice_url) . ");
            </script>";
            exit;

        } catch(Exception $e){
            $conn->rollback();
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); history.back();</script>";
            exit;
        }
    }
}

/* ================= SAVE PAYMENT ================= */
if(isset($_POST['save_payment'])){
    // CSRF Verification
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        die("CSRF token validation failed.");
    }
    
    $purchase_id = filter_var($_POST['purchase_id'], FILTER_VALIDATE_INT);
    $payment_amount = filter_var($_POST['payment_amount'], FILTER_VALIDATE_FLOAT);
    $payment_method = sanitize($_POST['payment_method']);
    $note = sanitize($_POST['note']);
    $payment_date = sanitize($_POST['payment_date']);

    if (!$purchase_id || $purchase_id <= 0) {
        die("Invalid purchase selected.");
    }
    if (!$payment_amount || $payment_amount <= 0) {
        die("Payment amount must be greater than 0.");
    }

    $stmt = $conn->prepare("SELECT p.* FROM purchases p INNER JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ? AND s.shop_id = ? LIMIT 1");
    $stmt->bind_param("ii", $purchase_id, $shop_id);
    $stmt->execute();
    $purchase = $stmt->get_result()->fetch_assoc();
    if(!$purchase){
        die("Purchase not found.");
    }

    $supplier_id = $purchase['supplier_id'];
    $current_due = $purchase['due_amount'];

    if($payment_amount > $current_due){
        die("Payment cannot exceed due amount: ৳".number_format($current_due,2));
    }

    if($payment_amount > 0){
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO supplier_payments (supplier_id, purchase_id, payment_amount, payment_method, note, payment_date) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param("iidsss", $supplier_id, $purchase_id, $payment_amount, $payment_method, $note, $payment_date);
            $stmt->execute();

            $new_paid = $purchase['paid_amount'] + $payment_amount;
            $new_due  = $purchase['due_amount'] - $payment_amount;
            
            $stmt2 = $conn->prepare("UPDATE purchases p INNER JOIN suppliers s ON s.id = p.supplier_id SET p.paid_amount=?, p.due_amount=? WHERE p.id=? AND s.shop_id=?");
            $stmt2->bind_param("ddii", $new_paid, $new_due, $purchase_id, $shop_id);
            $stmt2->execute();

            $stmt3 = $conn->prepare("UPDATE suppliers SET current_due = current_due - ? WHERE id=? AND shop_id=?");
            $stmt3->bind_param("dii", $payment_amount, $supplier_id, $shop_id);
            $stmt3->execute();

            $conn->commit();
            echo "<script>alert('Payment Saved Successfully!'); location.href='add_purchase.php';</script>";
            exit;

        } catch(Exception $e) {
            $conn->rollback();
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); history.back();</script>";
            exit;
        }
    }
}

/* ================= DELETE PURCHASE ================= */
if(isset($_POST['delete_purchase']) && isset($_POST['delete_token'])){
    // CSRF Verification
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        die("CSRF token validation failed.");
    }
    
    $id = filter_var($_POST['delete_purchase'], FILTER_VALIDATE_INT);
    if (!$id || $id <= 0) {
        die("Invalid purchase ID.");
    }
    
    $stmt = $conn->prepare("SELECT p.* FROM purchases p INNER JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ? AND s.shop_id = ? LIMIT 1");
    $stmt->bind_param("ii", $id, $shop_id);
    $stmt->execute();
    $purchase = $stmt->get_result()->fetch_assoc();

    if($purchase){
        $conn->begin_transaction();
        try {
            $supplier_id = $purchase['supplier_id'];
            $due_amount  = $purchase['due_amount'];
            
            $stmt = $conn->prepare("SELECT product_id, quantity FROM purchase_items WHERE purchase_id = ? AND shop_id = ?");
            $stmt->bind_param("ii", $id, $shop_id);
            $stmt->execute();
            $itemResult = $stmt->get_result();
            $updateStock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND shop_id = ?");

            while($item = $itemResult->fetch_assoc()){
                $qty = (float)$item['quantity'];
                $product_id = (int)$item['product_id'];
                $updateStock->bind_param("dii", $qty, $product_id, $shop_id);
                $updateStock->execute();
            }

            $stmt = $conn->prepare("DELETE FROM purchase_items WHERE purchase_id = ? AND shop_id = ?");
            $stmt->bind_param("ii", $id, $shop_id);
            $stmt->execute();
            $stmt = $conn->prepare("
                DELETE sp
                FROM supplier_payments sp
                INNER JOIN purchases p ON p.id = sp.purchase_id
                INNER JOIN suppliers s ON s.id = p.supplier_id
                WHERE sp.purchase_id = ? AND s.shop_id = ?
            ");
            $stmt->bind_param("ii", $id, $shop_id);
            $stmt->execute();

            $stmt = $conn->prepare("UPDATE suppliers SET current_due = current_due - ? WHERE id=? AND shop_id=?");
            $stmt->bind_param("dii", $due_amount, $supplier_id, $shop_id);
            $stmt->execute();

            if (!empty($purchase['invoice_image'])) {
                $imgPath = "../../uploads/invoices/" . $purchase['invoice_image'];
                if (file_exists($imgPath)) {
                    unlink($imgPath);
                }
            }

            $stmt = $conn->prepare("DELETE p FROM purchases p INNER JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ? AND s.shop_id = ?");
            $stmt->bind_param("ii", $id, $shop_id);
            $stmt->execute();
            $conn->commit();

        } catch(Exception $e) {
            $conn->rollback();
            echo "<script>alert('Delete failed: " . addslashes($e->getMessage()) . "');</script>";
        }
    }
    header("Location: add_purchase.php");
    exit;
}

/* ================= SUPPLIERS ================= */
$suppliers = $conn->query("SELECT * FROM suppliers WHERE shop_id = $shop_id ORDER BY supplier_name ASC");

/* ================= PRODUCTS ================= */
$products = $conn->query("SELECT * FROM products WHERE shop_id = $shop_id ORDER BY product_name ASC");

/* ================= PURCHASE LIST ================= */
$purchases = $conn->query("SELECT p.*, s.supplier_name FROM purchases p INNER JOIN suppliers s ON s.id=p.supplier_id WHERE s.shop_id = $shop_id ORDER BY p.id DESC");

/* ================= AUTO INVOICE ================= */
$invoice_no = "PUR".date("YmdHis");
$delete_token = bin2hex(random_bytes(32));
$_SESSION['delete_token'] = $delete_token;

// Get all products for JSON
$allProducts = [];
$productQuery = $conn->query("SELECT id, product_name, barcode, unit, purchase_price, sale_price FROM products WHERE shop_id = $shop_id ORDER BY product_name ASC");
while($p = $productQuery->fetch_assoc()) {
    $allProducts[] = $p;
}
$productsJson = json_encode($allProducts);
?>

<style>
.main{
    flex:1;
    padding:20px;
    background:#f8fafc;
    overflow-x: hidden;
}
.card-box{
    background:#fff;
    padding:15px;
    border-radius:12px;
    box-shadow:0 2px 10px rgba(0,0,0,.05);
    margin-bottom:15px;
}
.table td, .table th{
    vertical-align:middle;
}
.badge-id{
    background:#0f172a;
    color:#fff;
    padding:4px 8px;
    border-radius:20px;
    font-size:11px;
}
.invoice-thumb{
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 6px;
    cursor: pointer;
    border: 1px solid #ddd;
}
.btn-action{
    padding: 4px 8px;
    font-size: 12px;
    border-radius: 6px;
}

/* ================= PRODUCT SEARCH STYLES ================= */
.product-select-wrapper {
    position: relative;
    width: 100%;
    z-index: 9999 !important;
}

.product-select-wrapper .form-control {
    width: 100%;
    padding-right: 90px;
}

.product-select-wrapper .dropdown-menu {
    max-height: 350px;
    overflow-y: auto;
    width: 100%;
    min-width: 300px;
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 99999 !important;
    background: #ffffff;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.2);
    padding: 0;
    margin-top: 4px;
    display: none;
}

.product-select-wrapper .dropdown-menu.show {
    display: block !important;
}

.product-select-wrapper .dropdown-item {
    padding: 10px 14px;
    cursor: pointer;
    border-bottom: 1px solid #f3f4f6;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background 0.15s;
}

.product-select-wrapper .dropdown-item:hover {
    background: #eff6ff;
}

.product-select-wrapper .dropdown-item .product-name {
    font-weight: 500;
    color: #1f2937;
}

.product-select-wrapper .dropdown-item .product-barcode {
    font-size: 11px;
    color: #6b7280;
    background: #f3f4f6;
    padding: 2px 10px;
    border-radius: 12px;
    margin: 0 8px;
}

.product-select-wrapper .dropdown-item .product-price {
    font-size: 13px;
    color: #059669;
    font-weight: 600;
    background: #ecfdf5;
    padding: 2px 10px;
    border-radius: 12px;
}

.product-select-wrapper .search-loading {
    padding: 15px;
    text-align: center;
    color: #6b7280;
}

.product-select-wrapper .no-result {
    padding: 15px;
    text-align: center;
    color: #9ca3af;
}

.highlight {
    background: #fef08a;
    padding: 0 2px;
    border-radius: 2px;
}

/* ================= SCANNER BUTTONS ================= */
.scanner-btn-group {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    display: flex;
    border-radius: 0 6px 6px 0;
    overflow: hidden;
    z-index: 9998;
}

.scanner-btn-group .btn-scanner {
    height: 100%;
    border: none;
    padding: 0 12px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 4px;
}

.scanner-btn-group .btn-camera {
    background: #e0e7ff;
    color: #4338ca;
}
.scanner-btn-group .btn-camera:hover {
    background: #c7d2fe;
}
.scanner-btn-group .btn-camera:active {
    background: #818cf8;
    color: #fff;
}

.scanner-btn-group .btn-usb {
    background: #d1fae5;
    color: #059669;
}
.scanner-btn-group .btn-usb:hover {
    background: #a7f3d0;
}
.scanner-btn-group .btn-usb:active {
    background: #34d399;
    color: #fff;
}
.scanner-btn-group .btn-usb.active {
    background: #059669;
    color: #fff;
    animation: pulse 1s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
}

/* USB Scanner Status Indicator */
.usb-scanner-status {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #0f172a;
    color: #fff;
    padding: 12px 20px;
    border-radius: 12px;
    font-size: 14px;
    z-index: 99999;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    align-items: center;
    gap: 10px;
}
.usb-scanner-status.show {
    display: flex;
}
.usb-scanner-status .status-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
}
.usb-scanner-status .status-dot.active {
    background: #4ade80;
    animation: pulse 1s infinite;
}
.usb-scanner-status .status-dot.inactive {
    background: #ef4444;
}

/* ================= TABLE RESPONSIVE ================= */
.table-responsive {
    overflow-x: auto;
    margin-bottom: 15px;
}

#purchaseTable {
    min-width: 800px;
}

#purchaseTable td {
    padding: 8px 6px;
}

#purchaseTable .form-control {
    font-size: 14px;
    padding: 6px 10px;
}

/* ================= USB SCANNER TOAST ================= */
.toast-scanner {
    position: fixed;
    bottom: 80px;
    right: 20px;
    background: #1f2937;
    color: #fff;
    padding: 15px 25px;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    z-index: 99998;
    display: none;
    min-width: 300px;
    border-left: 4px solid #4ade80;
}
.toast-scanner.show {
    display: block;
    animation: slideUp 0.3s ease;
}
@keyframes slideUp {
    from { transform: translateY(20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
.toast-scanner .toast-title {
    font-weight: 600;
    margin-bottom: 4px;
}
.toast-scanner .toast-barcode {
    font-size: 18px;
    font-weight: 700;
    color: #4ade80;
    font-family: monospace;
}
.toast-scanner .toast-close {
    position: absolute;
    top: 5px;
    right: 10px;
    cursor: pointer;
    color: #9ca3af;
    background: none;
    border: none;
    font-size: 18px;
}
.toast-scanner .toast-close:hover {
    color: #fff;
}

@media(max-width:768px){
    .main{ padding:10px; }
    .table{ font-size:12px; }
    .btn-action{ padding: 2px 6px; font-size: 10px; }
    .product-select-wrapper .dropdown-item {
        flex-wrap: wrap;
        gap: 4px;
    }
    .product-select-wrapper .dropdown-menu {
        min-width: 200px;
        max-height: 250px;
    }
    .scanner-btn-group .btn-scanner {
        padding: 0 8px;
        font-size: 12px;
    }
    .product-select-wrapper .form-control {
        padding-right: 70px;
    }
}

/* ================= FIXED POSITION FOR DROPDOWN ================= */
.product-select-wrapper .dropdown-menu {
    position: fixed !important;
    top: auto !important;
    left: auto !important;
    max-width: 400px;
}

/* ================= EXTRA SPACING FOR TABLE ROWS ================= */
#purchaseBody tr {
    transition: all 0.2s;
}

#purchaseBody tr:hover {
    background: #f8fafc;
}

/* ================= TOTAL ROW STYLING ================= */
#subtotal, #delivery_charge, #grand_total, #paid_amount, #due_amount {
    font-weight: 600;
}

#subtotal {
    border-color: #059669;
    background: #f0fdf4;
}

#delivery_charge {
    border-color: #f59e0b;
    background: #fffbeb;
}

#grand_total {
    border-color: #3b82f6;
    background: #eff6ff;
    font-size: 18px;
}

#paid_amount {
    border-color: #8b5cf6;
    background: #f5f3ff;
}

#due_amount {
    border-color: #ef4444;
    background: #fef2f2;
}

/* ===== POS UI POLISH ===== */

body{
    background:#f1f5f9;
    font-family: "Segoe UI", sans-serif;
}

.main{
    padding:24px;
}

.card-box{
    background:#ffffff;
    border-radius:18px;
    padding:22px;
    box-shadow:0 10px 35px rgba(15,23,42,.08);
    border:1px solid #e2e8f0;
}

h3{
    font-weight:700;
    color:#0f172a;
}

.table{
    border-radius:12px;
    overflow:hidden;
}

.table thead th{
    background:#0f172a !important;
    color:#fff;
    font-size:14px;
    padding:14px;
    text-align:center;
}

.table tbody tr:hover{
    background:#f8fafc;
}

.form-control,
.form-select{
    border-radius:10px;
    border:1px solid #cbd5e1;
    min-height:42px;
}

.form-control:focus,
.form-select:focus{
    border-color:#2563eb;
    box-shadow:0 0 0 .2rem rgba(37,99,235,.15);
}

.btn{
    border-radius:10px;
    font-weight:600;
}

.btn-success{
    background:#16a34a;
    border-color:#16a34a;
}

.btn-success:hover{
    background:#15803d;
}

.btn-primary{
    background:#2563eb;
}

#purchaseTable input{
    font-size:14px;
}

.summary-box{
    background:#f8fafc;
    padding:20px;
    border-radius:15px;
    border:1px solid #e2e8f0;
}

@media(max-width:768px){
    .main{
        padding:10px;
    }

    .card-box{
        padding:15px;
    }
}

/* ================= ONE-LINE FORM ================= */
.form-row {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 8px;
}
.form-row .form-group {
    flex: 0 0 auto;
}
.form-row .form-group-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    margin-bottom: 2px;
    display: block;
}
.form-row .form-control,
.form-row .form-select {
    min-height: 36px;
    font-size: 13px;
    padding: 4px 10px;
}
.form-row .form-control-sm {
    min-height: 36px;
    font-size: 13px;
    padding: 4px 10px;
}
@media(max-width:992px){
    .form-row {
        flex-direction: column;
        gap: 4px;
    }
    .form-row .form-group {
        width: 100%;
    }
}
</style>

<div class="main">
    <h3>📦 Purchase Entry</h3>
    <?php if (isset($_GET['saved']) && $_GET['saved'] === '1'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> Purchase saved successfully. Invoice opened in a separate tab.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <hr>

    <form method="POST" enctype="multipart/form-data" id="purchaseForm" target="purchaseInvoiceTab">
        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
        
        <!-- ================= PURCHASE TABLE ================= -->
        <h5 class="mb-2">
            <i class="fas fa-box"></i> Purchase Products
            <button type="button" class="btn btn-sm btn-success ms-1" id="toggleUsbScanner">
                <i class="fas fa-usb"></i> USB Scanner
            </button>
        </h5>

        <div class="table-responsive">
            <table class="table table-bordered align-middle" id="purchaseTable">
                <thead class="table-dark">
                    <tr>
                        <th style="min-width: 280px; width: 28%;">Product</th>
                        <th style="min-width: 120px; width: 12%;">Barcode</th>
                        <th style="min-width: 80px; width: 8%;">Unit</th>
                        <th style="min-width: 80px; width: 9%;">Qty</th>
                        <th style="min-width: 120px; width: 12%;">Purchase Price</th>
                        <th style="min-width: 120px; width: 12%;">Sale Price</th>
                        <th style="min-width: 100px; width: 11%;">Total</th>
                        <th style="min-width: 80px; width: 8%;">Action</th>
                    </tr>
                </thead>
                <tbody id="purchaseBody">
                </tbody>
            </table>
        </div>

        <button type="button" class="btn btn-primary mb-3" id="addRow">
            <i class="fas fa-plus"></i> Add Product (F1)
        </button>

        <hr>

        <!-- ================= ONE-LINE FORM ================= -->
        <div class="card-box">
            <div class="form-row">
                <!-- Supplier -->
                <div class="form-group" style="flex: 2; min-width: 160px;">
                    <span class="form-group-label">👤 Supplier</span>
                    <select name="supplier_id" class="form-select" required>
                        <option value="">Select Supplier</option>
                        <?php 
                        $suppliers_for_select = $conn->query("SELECT * FROM suppliers WHERE shop_id = $shop_id ORDER BY supplier_name ASC");
                        while($s = $suppliers_for_select->fetch_assoc()){ 
                        ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['supplier_name']) ?></option>
                        <?php } ?>
                    </select>
                </div>

                <!-- Invoice No -->
                <div class="form-group" style="flex: 1.5; min-width: 120px;">
                    <span class="form-group-label">📄 Invoice No</span>
                    <input type="text" name="invoice_no" class="form-control" placeholder="Supplier Invoice">
                </div>

                <!-- Subtotal -->
                <div class="form-group" style="flex: 1; min-width: 90px;">
                    <span class="form-group-label">💰 Subtotal</span>
                    <input type="number" step="0.01" name="subtotal" id="subtotal" class="form-control" placeholder="0.00" readonly>
                </div>

                <!-- Delivery Charge -->
                <div class="form-group" style="flex: 1; min-width: 90px;">
                    <span class="form-group-label">🚚 Delivery</span>
                    <input type="number" step="0.01" name="delivery_charge" id="delivery_charge" class="form-control" placeholder="0.00" value="0">
                </div>

                <!-- Grand Total -->
                <div class="form-group" style="flex: 1; min-width: 90px;">
                    <span class="form-group-label">📊 Grand Total</span>
                    <input type="number" step="0.01" name="grand_total" id="grand_total" class="form-control" placeholder="0.00" readonly>
                </div>

                <!-- Paid Amount -->
                <div class="form-group" style="flex: 1; min-width: 90px;">
                    <span class="form-group-label">💵 Paid</span>
                    <input type="number" step="0.01" name="paid_amount" id="paid_amount" class="form-control" placeholder="0.00" value="0">
                </div>

                <!-- Payment Method -->
                <div class="form-group" style="flex: 1; min-width: 90px;">
                    <span class="form-group-label">💳 Method</span>
                    <select name="payment_method" class="form-select">
                        <option value="cash" selected>💰 Cash</option>
                        <option value="bank">🏦 Bank</option>
                        <option value="bkash">📱 bKash</option>
                        <option value="nagad">📱 Nagad</option>
                    </select>
                </div>

                <!-- Due Amount -->
                <div class="form-group" style="flex: 1; min-width: 90px;">
                    <span class="form-group-label">📌 Due</span>
                    <input type="number" step="0.01" name="due_amount" id="due_amount" class="form-control" placeholder="0.00" readonly>
                </div>

                <!-- Invoice Image -->
                <div class="form-group" style="flex: 1.5; min-width: 100px;">
                    <span class="form-group-label">🖼️ Image</span>
                    <input type="file" name="invoice_image" class="form-control" accept="image/*" id="invoice_image" style="padding: 2px 6px; min-height: 36px;">
                </div>

                <!-- Preview -->
                <div class="form-group" style="flex: 0.5; min-width: 40px;">
                    <img id="preview" src="" style="display:none; width:36px; height:36px; object-fit:cover; border-radius:6px; border:1px solid #ddd; margin-top:18px;">
                </div>

                <!-- Save Button -->
                <div class="form-group" style="flex: 0.8; min-width: 80px;">
                    <button type="submit" name="save_purchase" class="btn btn-success w-100" style="min-height: 36px; font-size: 14px; margin-top:18px;">
                        <i class="fas fa-save"></i> SAVE
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- ================= USB SCANNER TOAST ================= -->
<div class="toast-scanner" id="usbToast">
    <button class="toast-close" onclick="this.parentElement.classList.remove('show')">&times;</button>
    <div class="toast-title">
        <i class="fas fa-usb text-success"></i> USB Scanner Detected
    </div>
    <div class="toast-barcode" id="usbBarcode">---</div>
    <small class="text-muted">Press Enter to add product automatically</small>
</div>

<!-- ================= USB SCANNER STATUS ================= -->
<div class="usb-scanner-status" id="usbStatus">
    <span class="status-dot active" id="usbDot"></span>
    <span id="usbStatusText">USB Scanner Ready</span>
    <span class="text-muted ms-2" id="usbBarcodeCount" style="font-size:12px;"></span>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
// ================= PRODUCT DATA =================
const allProducts = <?= $productsJson ?>;

// ================= SAVE + OPEN INVOICE TAB =================
// Open the named invoice tab directly from the submit event. If the browser blocks
// popups, the form safely falls back to the current tab.
$('#purchaseForm').on('submit', function() {
    const popup = window.open('', 'purchaseInvoiceTab');

    if (popup) {
        try {
            popup.document.open();
            popup.document.write(`
                <!doctype html>
                <html><head><title>Generating Invoice...</title>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <style>
                    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f1f5f9;font-family:Arial,sans-serif;color:#0f172a}
                    .box{background:#fff;padding:28px 34px;border-radius:16px;box-shadow:0 12px 35px rgba(15,23,42,.12);text-align:center}
                    .spinner{width:34px;height:34px;border:4px solid #e2e8f0;border-top-color:#2563eb;border-radius:50%;margin:0 auto 14px;animation:spin .8s linear infinite}
                    @keyframes spin{to{transform:rotate(360deg)}}
                </style></head>
                <body><div class="box"><div class="spinner"></div><strong>Saving purchase...</strong><div>Generating invoice</div></div></body></html>
            `);
            popup.document.close();
        } catch (e) {}
        this.setAttribute('target', 'purchaseInvoiceTab');
    } else {
        this.removeAttribute('target');
    }
});

// ================= USB SCANNER =================
let usbScannerActive = false;
let usbBarcodeBuffer = '';
let usbBarcodeTimeout = null;
let usbScannedCount = 0;

// Toggle USB Scanner
$('#toggleUsbScanner').on('click', function() {
    usbScannerActive = !usbScannerActive;
    $(this).toggleClass('active');
    if(usbScannerActive) {
        $(this).html('<i class="fas fa-usb"></i> USB ON');
        $(this).addClass('btn-success').removeClass('btn-outline-success');
        showUsbStatus(true, 'USB Scanner Active - Scan barcode now');
        showToast('USB Scanner Activated', 'Ready to scan');
    } else {
        $(this).html('<i class="fas fa-usb"></i> USB Scanner');
        $(this).removeClass('btn-success').addClass('btn-outline-success');
        showUsbStatus(false, 'USB Scanner Off');
        usbBarcodeBuffer = '';
    }
});

// Keyboard listener for USB scanner (HID Keyboard Emulation)
$(document).on('keydown', function(e) {
    if(!usbScannerActive) return;
    
    // Check if it's a printable character
    if(e.key.length === 1) {
        // Skip if in input/textarea/select
        if(e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
            return;
        }
        
        // Add to buffer
        usbBarcodeBuffer += e.key;
        clearTimeout(usbBarcodeTimeout);
        
        // Set timeout to process barcode (scanners usually send Enter after scan)
        usbBarcodeTimeout = setTimeout(() => {
            if(usbBarcodeBuffer.length > 3) {
                processUsbBarcode(usbBarcodeBuffer);
            }
            usbBarcodeBuffer = '';
        }, 100);
    }
    
    // Enter key - process barcode immediately
    if(e.key === 'Enter' && usbBarcodeBuffer.length > 3) {
        e.preventDefault();
        processUsbBarcode(usbBarcodeBuffer);
        usbBarcodeBuffer = '';
        clearTimeout(usbBarcodeTimeout);
    }
});

function processUsbBarcode(barcode) {
    barcode = barcode.trim();
    if(!barcode) return;
    
    usbScannedCount++;
    showUsbStatus(true, 'Scanned: ' + barcode);
    showToast('USB Scanner', barcode);
    $('#usbBarcodeCount').text('(' + usbScannedCount + ' scanned)');
    
    // Find product by barcode
    const product = allProducts.find(p => p.barcode === barcode);
    if(product) {
        addNewRow(product);
        showToast('✅ Product Found', product.product_name);
    } else {
        showToast('❌ Not Found', 'Barcode: ' + barcode);
    }
}

function showToast(title, message) {
    const toast = $('#usbToast');
    $('#usbBarcode').text(message);
    toast.addClass('show');
    clearTimeout(toast.data('hideTimeout'));
    toast.data('hideTimeout', setTimeout(() => {
        toast.removeClass('show');
    }, 3000));
}

function showUsbStatus(active, text) {
    const status = $('#usbStatus');
    if(active) {
        status.addClass('show');
        $('#usbDot').removeClass('inactive').addClass('active');
        $('#usbStatusText').text(text);
    } else {
        status.removeClass('show');
        $('#usbDot').removeClass('active').addClass('inactive');
        $('#usbStatusText').text(text);
    }
}

// ================= CALCULATE GRAND TOTAL WITH DELIVERY =================
function calculateGrand(){
    let subtotal = 0;
    $(".total").each(function(){
        subtotal += parseFloat($(this).val()) || 0;
    });
    let delivery = parseFloat($("#delivery_charge").val()) || 0;
    let grand = subtotal + delivery;
    
    $("#subtotal").val(subtotal.toFixed(2));
    $("#grand_total").val(grand.toFixed(2)).trigger("change");
}

// ================= CALCULATE DUE =================
function calculateDue(){
    let total = parseFloat($("#grand_total").val()) || 0;
    let paid = parseFloat($("#paid_amount").val()) || 0;
    
    if(paid > total){
        paid = total;
        $("#paid_amount").val(total);
    }
    
    let due = total - paid;
    $("#due_amount").val(due.toFixed(2));
}

// ================= EVENT BINDINGS =================
$("#delivery_charge").on("keyup change", function(){
    calculateGrand();
});

$("#grand_total,#paid_amount").on("keyup change", calculateDue);

// ================= IMAGE PREVIEW =================
$("#invoice_image").on("change", function(){
    let file = this.files[0];
    if(file){
        let reader = new FileReader();
        reader.onload = function(e){
            $("#preview").attr("src", e.target.result).show();
        }
        reader.readAsDataURL(file);
    }
});

// ================= ADD ROW =================
let row = 0;

$("#addRow").click(function(){
    addNewRow();
});

function addNewRow(productData = null) {
    let html = `
    <tr>
        <td>
            <div class="product-select-wrapper">
                <input type="text" 
                       class="form-control product-search" 
                       placeholder="🔍 Search product by name or barcode..."
                       autocomplete="off">
                <div class="scanner-btn-group">
                    
                    <button type="button" class="btn-scanner btn-usb" onclick="toggleUsbForRow(this)" title="USB Scanner (Ctrl+U)">
                        <i class="fas fa-usb"></i>
                    </button>
                </div>
                <input type="hidden" name="product_id[]" class="product-id" value="">
                <div class="dropdown-menu" style="position: fixed !important;">
                    <div class="search-loading">Loading products...</div>
                </div>
            </div>
        </td>
        <td>
            <input type="text" name="barcode[]" class="form-control barcode" readonly style="background: #f9fafb;">
        </td>
        <td>
            <input type="text" name="unit[]" class="form-control unit" readonly style="background: #f9fafb;">
        </td>
        <td>
            <input type="number" step="0.01" value="1" name="qty[]" class="form-control qty" min="0.01">
        </td>
        <td>
            <input type="number" step="0.01" name="purchase_price[]" class="form-control purchase_price" min="0">
        </td>
        <td>
            <input type="number" step="0.01" name="sale_price[]" class="form-control sale_price" min="0">
        </td>
        <td>
            <input type="text" name="total[]" class="form-control total" readonly style="background: #f0fdf4; font-weight: 600;">
        </td>
        <td>
            <button type="button" class="btn btn-danger btn-sm removeRow">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    </tr>
    `;

    $("#purchaseBody").append(html);
    
    const $row = $("#purchaseBody tr:last-child");
    initProductSearch($row);
    
    if(productData) {
        $row.find('.product-id').val(productData.id);
        $row.find('.product-search').val(productData.product_name);
        $row.find('.barcode').val(productData.barcode);
        $row.find('.unit').val(productData.unit);
        $row.find('.purchase_price').val(productData.purchase_price);
        $row.find('.sale_price').val(productData.sale_price);
        calculateRow($row);
        
        // Highlight the row
        $row.css('background', '#d1fae5');
        setTimeout(() => {
            $row.css('background', '');
        }, 2000);
    }
    
    setTimeout(() => {
        $row.find('.product-search').focus();
    }, 100);
}

// Toggle USB for specific row
function toggleUsbForRow(btn) {
    $(btn).toggleClass('active');
    if($(btn).hasClass('active')) {
        $(btn).css('background', '#059669').css('color', '#fff');
        showToast('USB Scanner', 'Row selected for USB scanning');
    } else {
        $(btn).css('background', '').css('color', '');
    }
}

// ================= PRODUCT SEARCH =================
function initProductSearch($row) {
    const $searchInput = $row.find('.product-search');
    const $dropdown = $row.find('.dropdown-menu');
    const $productId = $row.find('.product-id');
    const $barcode = $row.find('.barcode');
    const $unit = $row.find('.unit');
    const $purchasePrice = $row.find('.purchase_price');
    const $salePrice = $row.find('.sale_price');
    
    let selectedProduct = null;
    let debounceTimeout = null;
    
    function filterProducts(query) {
        query = query.toLowerCase().trim();
        if(query.length === 0) {
            return allProducts.slice(0, 30);
        }
        
        return allProducts.filter(p => 
            p.product_name.toLowerCase().includes(query) || 
            (p.barcode && p.barcode.toLowerCase().includes(query))
        ).slice(0, 50);
    }
    
    function renderDropdown(products) {
        if(!products || products.length === 0) {
            $dropdown.html('<div class="no-result"><i class="fas fa-inbox"></i> No products found</div>');
            $dropdown.addClass('show');
            return;
        }
        
        let html = '';
        const searchQuery = $searchInput.val().trim();
        
        products.forEach(p => {
            let displayName = p.product_name;
            if(searchQuery) {
                displayName = p.product_name.replace(
                    new RegExp(searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), 
                    match => `<span class="highlight">${match}</span>`
                );
            }
            
            html += `
                <div class="dropdown-item" 
                     data-id="${p.id}" 
                     data-barcode="${p.barcode || ''}" 
                     data-unit="${p.unit || ''}" 
                     data-purchase="${p.purchase_price || 0}" 
                     data-sale="${p.sale_price || 0}">
                    <span class="product-name">${displayName}</span>
                    ${p.barcode ? `<span class="product-barcode">📷 ${p.barcode}</span>` : ''}
                    <span class="product-price">৳${parseFloat(p.purchase_price || 0).toFixed(2)}</span>
                </div>
            `;
        });
        
        $dropdown.html(html);
        
        const inputRect = $searchInput[0].getBoundingClientRect();
        $dropdown.css({
            'position': 'fixed',
            'top': (inputRect.bottom + 5) + 'px',
            'left': inputRect.left + 'px',
            'width': Math.min(inputRect.width, 400) + 'px',
            'max-width': '400px',
            'z-index': '99999'
        });
        
        $dropdown.addClass('show');
    }
    
    function debounceSearch(query) {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            const filtered = filterProducts(query);
            renderDropdown(filtered);
        }, 200);
    }
    
    $searchInput.on('input', function() {
        const query = $(this).val();
        debounceSearch(query);
    });
    
    $searchInput.on('focus', function() {
        const query = $(this).val();
        const filtered = filterProducts(query);
        renderDropdown(filtered);
    });
    
    $(document).on('click', function(e) {
        if(!$row.find('.product-select-wrapper').is(e.target) && 
           !$row.find('.product-select-wrapper').has(e.target).length) {
            $dropdown.removeClass('show');
        }
    });
    
    $dropdown.on('click', '.dropdown-item', function() {
        const $item = $(this);
        const id = $item.data('id');
        const barcode = $item.data('barcode');
        const unit = $item.data('unit');
        const purchase = $item.data('purchase');
        const sale = $item.data('sale');
        const name = $item.text().trim();
        
        selectedProduct = allProducts.find(p => p.id === id);
        
        $productId.val(id);
        $searchInput.val(name);
        $barcode.val(barcode);
        $unit.val(unit);
        $purchasePrice.val(purchase);
        $salePrice.val(sale);
        
        $dropdown.removeClass('show');
        calculateRow($row);
        $searchInput.focus();
        $searchInput.select();
    });
    
    $searchInput.on('keydown', function(e) {
        const $items = $dropdown.find('.dropdown-item');
        if($items.length === 0) return;
        
        let currentIndex = $items.index($items.filter('.active'));
        
        if(e.key === 'ArrowDown') {
            e.preventDefault();
            currentIndex = Math.min(currentIndex + 1, $items.length - 1);
        } else if(e.key === 'ArrowUp') {
            e.preventDefault();
            currentIndex = Math.max(currentIndex - 1, 0);
        } else if(e.key === 'Enter') {
            e.preventDefault();
            if(currentIndex >= 0 && currentIndex < $items.length) {
                $items.eq(currentIndex).click();
            }
            return;
        } else if(e.key === 'Escape') {
            $dropdown.removeClass('show');
            return;
        }
        
        $items.removeClass('active');
        if(currentIndex >= 0 && currentIndex < $items.length) {
            $items.eq(currentIndex).addClass('active');
            $items.eq(currentIndex)[0].scrollIntoView({ block: 'nearest' });
        }
    });
}

// ================= ROW CALCULATIONS =================
function calculateRow(row){
    let qty = parseFloat(row.find(".qty").val()) || 0;
    let price = parseFloat(row.find(".purchase_price").val()) || 0;
    let total = qty * price;
    row.find(".total").val(total.toFixed(2));
    calculateGrand();
}

$(document).on("keyup change", ".qty, .purchase_price", function(){
    let row = $(this).closest("tr");
    calculateRow(row);
});

$(document).on("click", ".removeRow", function(){
    if($("#purchaseBody tr").length > 1) {
        $(this).closest("tr").remove();
        calculateGrand();
    } else {
        alert("You must have at least one product row.");
    }
});

// ================= KEYBOARD SHORTCUTS =================
$(document).on('keydown', function(e) {
    // Ctrl + U - USB Scanner Toggle
    if(e.ctrlKey && e.key === 'u') {
        e.preventDefault();
        $('#toggleUsbScanner').click();
    }
    // F1 - Add Row
    if(e.key === 'F1') {
        e.preventDefault();
        $('#addRow').click();
    }
    // Escape - Close dropdowns
    if(e.key === 'Escape') {
        $('.dropdown-menu.show').removeClass('show');
    }
});

// ================= INITIALIZE =================
$(document).ready(function() {
    $('#addRow').click();
    
    // Show USB scanner status
    showUsbStatus(false, 'USB Scanner Off');
    
    setTimeout(() => {
        $('#purchaseBody .product-search:first').focus();
    }, 300);
});
</script>

<?php include "../footer.php"; ?>