<?php
session_start();
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(false);


if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "../../config/db.php";
$shop_id = tenantShopId();

// ============================================================
// GET PURCHASE DATA
// ============================================================
$purchase_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($purchase_id <= 0) {
    $_SESSION['rv_dashboard_flash'] = ['type' => 'error', 'message' => 'Invalid purchase ID.'];
    header("Location: purchase_list.php");
    exit();
}

// Get purchase details
$stmt = $conn->prepare("
    SELECT p.*, s.supplier_name 
    FROM purchases p
    INNER JOIN suppliers s ON s.id = p.supplier_id
    WHERE p.id = ? AND s.shop_id = ?
");
$stmt->bind_param("ii", $purchase_id, $shop_id);
$stmt->execute();
$purchase = $stmt->get_result()->fetch_assoc();

if (!$purchase) {
    $_SESSION['rv_dashboard_flash'] = ['type' => 'error', 'message' => 'Purchase not found.'];
    header("Location: purchase_list.php");
    exit();
}

// Get purchase items
$stmt = $conn->prepare("
    SELECT * FROM purchase_items WHERE purchase_id = ? AND shop_id = ?
");
$stmt->bind_param("ii", $purchase_id, $shop_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get suppliers for dropdown
$suppliers = $conn->query("SELECT id, supplier_name FROM suppliers WHERE shop_id = " . (int)$shop_id . " ORDER BY supplier_name");

// ============================================================
// UPDATE PURCHASE
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_purchase'])) {
    try {
        $supplier_id = (int)($_POST['supplier_id'] ?? 0);
        $invoice_no = trim($_POST['invoice_no'] ?? '');
        $grand_total = (float)($_POST['grand_total'] ?? 0);
        $paid_amount = (float)($_POST['paid_amount'] ?? 0);
        
        if ($supplier_id <= 0) throw new Exception('Please select a supplier.');
        if ($grand_total <= 0) throw new Exception('Grand total must be greater than 0.');

        $supplierCheck = $conn->prepare("SELECT id FROM suppliers WHERE id = ? AND shop_id = ? LIMIT 1");
        $supplierCheck->bind_param("ii", $supplier_id, $shop_id);
        $supplierCheck->execute();
        if (!$supplierCheck->get_result()->fetch_assoc()) {
            throw new Exception('Selected supplier does not belong to your shop.');
        }
        
        // Calculate due
        $due_amount = $grand_total - $paid_amount;
        if ($due_amount < 0) {
            throw new Exception('Paid amount cannot be greater than grand total.');
        }
        
        $conn->begin_transaction();
        
        // Update purchase
        $stmt = $conn->prepare("
            UPDATE purchases p
            INNER JOIN suppliers old_s ON old_s.id = p.supplier_id
            SET p.supplier_id = ?, p.invoice_no = ?, p.grand_total = ?, p.paid_amount = ?, p.due_amount = ?
            WHERE p.id = ? AND old_s.shop_id = ?
        ");
        $stmt->bind_param("isdddii", $supplier_id, $invoice_no, $grand_total, $paid_amount, $due_amount, $purchase_id, $shop_id);
        $stmt->execute();
        
        // Delete old items and insert new ones
        $stmt = $conn->prepare("DELETE FROM purchase_items WHERE purchase_id = ? AND shop_id = ?");
        $stmt->bind_param("ii", $purchase_id, $shop_id);
        $stmt->execute();
        
        // Insert new items
        if (isset($_POST['products']) && is_array($_POST['products'])) {
            foreach ($_POST['products'] as $item) {
                $product_id = (int)($item['product_id'] ?? 0);
                $quantity = (float)($item['quantity'] ?? 0);
                $purchase_price = (float)($item['purchase_price'] ?? 0);
                $sale_price = (float)($item['sale_price'] ?? 0);

                if ($product_id <= 0 || $quantity <= 0) {
                    continue;
                }

                $productStmt = $conn->prepare("SELECT category_id, brand_id, product_name, sku, barcode, unit FROM products WHERE id = ? AND shop_id = ? LIMIT 1");
                $productStmt->bind_param("ii", $product_id, $shop_id);
                $productStmt->execute();
                $product = $productStmt->get_result()->fetch_assoc();
                if (!$product) {
                    throw new Exception('One or more selected products do not belong to your shop.');
                }

                $category_id = (int)$product['category_id'];
                $brand_id = $product['brand_id'] !== null ? (int)$product['brand_id'] : null;
                $product_name = (string)$product['product_name'];
                $sku = (string)($product['sku'] ?? '');
                $barcode = (string)($product['barcode'] ?? '');
                $unit = (string)($product['unit'] ?? 'kg');
                $total = $quantity * $purchase_price;

                $stmt = $conn->prepare("
                    INSERT INTO purchase_items 
                    (purchase_id, shop_id, product_id, category_id, brand_id, product_name, sku, barcode, purchase_price, sale_price, quantity, unit, total) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param(
                    "iiiiisssdddsd",
                    $purchase_id, $shop_id, $product_id, $category_id, $brand_id,
                    $product_name, $sku, $barcode, $purchase_price, $sale_price,
                    $quantity, $unit, $total
                );
                $stmt->execute();
            }
        }
        
        // Update supplier current_due if needed
        if (tableExists($conn, 'suppliers') && columnExists($conn, 'suppliers', 'current_due')) {
            // Recalculate supplier due
            $stmt = $conn->prepare("
                SELECT IFNULL(SUM(grand_total - paid_amount), 0) as total_due 
                FROM purchases p
                INNER JOIN suppliers s ON s.id = p.supplier_id
                WHERE p.supplier_id = ? AND s.shop_id = ?
            ");
            $stmt->bind_param("ii", $supplier_id, $shop_id);
            $stmt->execute();
            $total_due = $stmt->get_result()->fetch_assoc()['total_due'] ?? 0;
            
            $stmt = $conn->prepare("UPDATE suppliers SET current_due = ? WHERE id = ? AND shop_id = ?");
            $stmt->bind_param("dii", $total_due, $supplier_id, $shop_id);
            $stmt->execute();
        }
        
        $conn->commit();
        $_SESSION['rv_dashboard_flash'] = ['type' => 'success', 'message' => 'Purchase updated successfully.'];
        header("Location: purchase_list.php");
        exit();
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['rv_dashboard_flash'] = ['type' => 'error', 'message' => $e->getMessage()];
        header("Location: edit_purchase.php?id=" . $purchase_id);
        exit();
    }
}

// ============================================================
// FUNCTIONS
// ============================================================
function tableExists($conn, $table) {
    static $cache = [];
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($table === '') return false;
    if (isset($cache[$table])) return $cache[$table];

    $stmt = $conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1");
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_row() : [0];
    $cache[$table] = ((int)($row[0] ?? 0) > 0);
    return $cache[$table];
}

function columnExists($conn, $table, $column) {
    static $cache = [];
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $column = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    if ($table === '' || $column === '') return false;

    $key = $table . '.' . $column;
    if (isset($cache[$key])) return $cache[$key];

    $stmt = $conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
    $stmt->bind_param("ss", $table, $column);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_row() : [0];
    $cache[$key] = ((int)($row[0] ?? 0) > 0);
    return $cache[$key];
}

include "../header.php";
include "../sidebar.php";
?>


<style>
/* ===== MAIN LAYOUT FIX ===== */
.main {
    padding: 20px;
    background: #f8fafc;
    min-height: 100vh;
    width: 100%;
    flex: 1;
}

.card-box {
    background: #fff;
    padding: 20px;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(0,0,0,.06);
    margin-bottom: 20px;
    width: 100%;
}

/* Form Styles */
.form-label {
    font-weight: 600;
    font-size: 14px;
    margin-bottom: 4px;
}

.form-control, .form-select {
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    padding: 8px 12px;
    font-size: 14px;
}

.form-control:focus, .form-select:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.btn {
    border-radius: 8px;
    padding: 8px 20px;
    font-weight: 600;
    font-size: 14px;
}

.btn-primary {
    background: #2563eb;
    border: none;
}
.btn-primary:hover {
    background: #1d4ed8;
}

.btn-danger {
    background: #dc2626;
    border: none;
}
.btn-danger:hover {
    background: #b91c1c;
}

.btn-success {
    background: #16a34a;
    border: none;
}
.btn-success:hover {
    background: #15803d;
}

.btn-warning {
    background: #f59e0b;
    border: none;
    color: #fff;
}
.btn-warning:hover {
    background: #d97706;
    color: #fff;
}

/* Item Row */
.item-row {
    background: #f8fafc;
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 10px;
    border: 1px solid #e2e8f0;
    position: relative;
}

.item-row .remove-item {
    position: absolute;
    top: -8px;
    right: -8px;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #dc2626;
    color: #fff;
    border: none;
    font-size: 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}
.item-row .remove-item:hover {
    background: #b91c1c;
}

/* Flash Message */
.rv-flash {
    padding: 12px 18px;
    border-radius: 8px;
    margin-bottom: 16px;
    font-weight: 700;
}
.rv-flash-success {
    background: #dcfce7;
    color: #166534;
    border-left: 4px solid #22c55e;
}
.rv-flash-error {
    background: #fee2e2;
    color: #991b1b;
    border-left: 4px solid #ef4444;
}

@media (max-width: 768px) {
    .main {
        padding: 12px;
    }
    .card-box {
        padding: 12px;
    }
}
</style>


<div class="main">

<!-- Flash Message -->
<?php 
$flash_message = '';
if (!empty($_SESSION['rv_dashboard_flash'])) {
    $flash_message = $_SESSION['rv_dashboard_flash'];
    unset($_SESSION['rv_dashboard_flash']);
}
if (!empty($flash_message)): ?>
    <div class="rv-flash rv-flash-<?= $flash_message['type'] ?>">
        <?= htmlspecialchars($flash_message['message']) ?>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h3 class="m-0">✏️ Edit Purchase</h3>
    <div>
        <a href="purchase_list.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<!-- Purchase Form -->
<div class="card-box">
    <form method="POST" action="">
        <input type="hidden" name="update_purchase" value="1">
        
        <!-- Basic Info -->
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Supplier <span class="text-danger">*</span></label>
                <select name="supplier_id" class="form-select" required>
                    <option value="">Select Supplier</option>
                    <?php while($s = $suppliers->fetch_assoc()): ?>
                        <option value="<?= $s['id'] ?>" <?= $s['id'] == $purchase['supplier_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s['supplier_name']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Invoice No</label>
                <input type="text" name="invoice_no" class="form-control" value="<?= htmlspecialchars($purchase['invoice_no'] ?? '') ?>" placeholder="Optional">
            </div>
            <div class="col-md-4">
                <label class="form-label">Date</label>
                <input type="text" class="form-control" value="<?= date('d-m-Y', strtotime($purchase['created_at'])) ?>" readonly disabled>
            </div>
        </div>

        <hr>

        <!-- Purchase Items -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold m-0">Purchase Items</h5>
            <button type="button" class="btn btn-success btn-sm" onclick="addItemRow()">
                <i class="fas fa-plus"></i> Add Item
            </button>
        </div>

        <div id="itemsContainer">
            <?php if (!empty($items)): ?>
                <?php foreach ($items as $index => $item): ?>
                    <div class="item-row">
                        <button type="button" class="remove-item" onclick="removeItem(this)" <?= count($items) <= 1 ? 'style="display:none"' : '' ?>>&times;</button>
                        <div class="row g-2">
                            <div class="col-md-3">
                                <label class="form-label">Product Name</label>
                                <input type="text" name="products[<?= $index ?>][product_name]" class="form-control" value="<?= htmlspecialchars($item['product_name'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Product ID</label>
                                <input type="number" name="products[<?= $index ?>][product_id]" class="form-control" value="<?= $item['product_id'] ?? 0 ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Category ID</label>
                                <input type="number" name="products[<?= $index ?>][category_id]" class="form-control" value="<?= $item['category_id'] ?? 0 ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Brand ID</label>
                                <input type="number" name="products[<?= $index ?>][brand_id]" class="form-control" value="<?= $item['brand_id'] ?? 0 ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">SKU</label>
                                <input type="text" name="products[<?= $index ?>][sku]" class="form-control" value="<?= htmlspecialchars($item['sku'] ?? '') ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Barcode</label>
                                <input type="text" name="products[<?= $index ?>][barcode]" class="form-control" value="<?= htmlspecialchars($item['barcode'] ?? '') ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Quantity</label>
                                <input type="number" step="0.01" name="products[<?= $index ?>][quantity]" class="form-control item-quantity" value="<?= $item['quantity'] ?? 0 ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Unit</label>
                                <input type="text" name="products[<?= $index ?>][unit]" class="form-control" value="<?= htmlspecialchars($item['unit'] ?? 'kg') ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Purchase Price</label>
                                <input type="number" step="0.01" name="products[<?= $index ?>][purchase_price]" class="form-control item-price" value="<?= $item['purchase_price'] ?? 0 ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Sale Price</label>
                                <input type="number" step="0.01" name="products[<?= $index ?>][sale_price]" class="form-control" value="<?= $item['sale_price'] ?? 0 ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Total</label>
                                <input type="text" class="form-control item-total" value="0.00" readonly>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="item-row">
                    <button type="button" class="remove-item" onclick="removeItem(this)" style="display:none">&times;</button>
                    <div class="row g-2">
                        <div class="col-md-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="products[0][product_name]" class="form-control" placeholder="Product Name" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Product ID</label>
                            <input type="number" name="products[0][product_id]" class="form-control" placeholder="ID">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Category ID</label>
                            <input type="number" name="products[0][category_id]" class="form-control" placeholder="Cat ID">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Brand ID</label>
                            <input type="number" name="products[0][brand_id]" class="form-control" placeholder="Brand ID">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">SKU</label>
                            <input type="text" name="products[0][sku]" class="form-control" placeholder="SKU">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Barcode</label>
                            <input type="text" name="products[0][barcode]" class="form-control" placeholder="Barcode">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Quantity</label>
                            <input type="number" step="0.01" name="products[0][quantity]" class="form-control item-quantity" placeholder="Qty" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Unit</label>
                            <input type="text" name="products[0][unit]" class="form-control" value="kg">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Purchase Price</label>
                            <input type="number" step="0.01" name="products[0][purchase_price]" class="form-control item-price" placeholder="Price" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Sale Price</label>
                            <input type="number" step="0.01" name="products[0][sale_price]" class="form-control" placeholder="Sale Price">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Total</label>
                            <input type="text" class="form-control item-total" value="0.00" readonly>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <hr>

        <!-- Totals -->
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Grand Total</label>
                <input type="number" step="0.01" name="grand_total" id="grandTotal" class="form-control" value="<?= $purchase['grand_total'] ?? 0 ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Paid Amount</label>
                <input type="number" step="0.01" name="paid_amount" id="paidAmount" class="form-control" value="<?= $purchase['paid_amount'] ?? 0 ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Due Amount</label>
                <input type="text" id="dueAmount" class="form-control" value="<?= number_format(($purchase['grand_total'] ?? 0) - ($purchase['paid_amount'] ?? 0), 2) ?>" readonly>
            </div>
        </div>

        <div class="mt-4 text-end">
            <a href="purchase_list.php" class="btn btn-secondary me-2">Cancel</a>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Purchase
            </button>
        </div>
    </form>
</div>

</div>

<?php include "../footer.php"; ?>

<script>
// ============================================================
// ITEM ROW MANAGEMENT
// ============================================================
let itemCounter = <?= count($items) ?>;

function addItemRow() {
    const container = document.getElementById('itemsContainer');
    const index = itemCounter++;
    
    const row = document.createElement('div');
    row.className = 'item-row';
    row.innerHTML = `
        <button type="button" class="remove-item" onclick="removeItem(this)">&times;</button>
        <div class="row g-2">
            <div class="col-md-3">
                <label class="form-label">Product Name</label>
                <input type="text" name="products[${index}][product_name]" class="form-control" placeholder="Product Name" required>
            </div>
            <div class="col-md-2">
                <label class="form-label">Product ID</label>
                <input type="number" name="products[${index}][product_id]" class="form-control" placeholder="ID">
            </div>
            <div