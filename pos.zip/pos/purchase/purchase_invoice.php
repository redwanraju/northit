<?php
session_start();
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(false);
$shop_id = tenantShopId();


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: same-origin');

include '../../config/db.php';

/*
 |--------------------------------------------------------------------------
 | BUSINESS INFORMATION
 |--------------------------------------------------------------------------
 | Edit only these values to place your own business information on invoices.
 | Session values are used automatically when your login system provides them.
 */
$company = [
    'name'          => $_SESSION['shop_name']    ?? 'উত্তরা খাদ্য ভান্ডার',
    'address'       => $_SESSION['shop_address'] ?? 'sector 14,road 23, house 02, uttara, dhaka',
    'mobile'        => $_SESSION['shop_mobile']  ?? '01813370808',
    'hotline'       => $_SESSION['shop_hotline'] ?? '',
    'email'         => $_SESSION['shop_email']   ?? 'uttarakhaddovandar@gmail.com',
    'trade_license' => $_SESSION['trade_license'] ?? '',
    'footer'        => 'PRODUCT QUALITY OUR FIRST PRIORITY',
];

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function money($value)
{
    return number_format((float)$value, 2);
}

function underThousandWords($number)
{
    $ones = [
        0 => '', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five',
        6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine', 10 => 'Ten',
        11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen',
        15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen'
    ];

    $tens = [
        2 => 'Twenty', 3 => 'Thirty', 4 => 'Forty', 5 => 'Fifty',
        6 => 'Sixty', 7 => 'Seventy', 8 => 'Eighty', 9 => 'Ninety'
    ];

    $number = (int)$number;
    $parts = [];

    if ($number >= 100) {
        $parts[] = $ones[(int)floor($number / 100)] . ' Hundred';
        $number %= 100;
    }

    if ($number >= 20) {
        $parts[] = $tens[(int)floor($number / 10)];
        $number %= 10;
        if ($number > 0) {
            $parts[] = $ones[$number];
        }
    } elseif ($number > 0) {
        $parts[] = $ones[$number];
    }

    return trim(implode(' ', $parts));
}

function numberToWordsBDT($amount)
{
    $amount = round((float)$amount, 2);
    $taka = (int)floor($amount);
    $paisa = (int)round(($amount - $taka) * 100);

    if ($taka === 0) {
        $words = 'Zero';
    } else {
        $parts = [];
        $groups = [
            10000000 => 'Crore',
            100000   => 'Lakh',
            1000     => 'Thousand',
            1        => ''
        ];

        foreach ($groups as $divisor => $label) {
            if ($taka >= $divisor) {
                $chunk = (int)floor($taka / $divisor);
                $taka %= $divisor;
                $chunkWords = underThousandWords($chunk);
                if ($chunkWords !== '') {
                    $parts[] = trim($chunkWords . ' ' . $label);
                }
            }
        }
        $words = implode(' ', $parts);
    }

    $result = trim($words) . ' Taka';
    if ($paisa > 0) {
        $result .= ' and ' . underThousandWords($paisa) . ' Paisa';
    }

    return strtoupper($result . ' Only');
}

$purchaseId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$purchaseId || $purchaseId < 1) {
    http_response_code(400);
    exit('Invalid purchase invoice ID.');
}

$stmt = $conn->prepare(
    "SELECT
        p.*,
        s.supplier_name,
        s.phone AS supplier_phone,
        s.email AS supplier_email,
        s.address AS supplier_address
     FROM purchases p
     INNER JOIN suppliers s ON s.id = p.supplier_id
     WHERE p.id = ? AND s.shop_id = ?
     LIMIT 1"
);

if (!$stmt) {
    http_response_code(500);
    exit('Unable to prepare invoice query.');
}

$stmt->bind_param('ii', $purchaseId, $shop_id);
$stmt->execute();
$purchaseResult = $stmt->get_result();
$purchase = $purchaseResult->fetch_assoc();
$stmt->close();

if (!$purchase) {
    http_response_code(404);
    exit('Purchase invoice not found.');
}

$itemStmt = $conn->prepare(
    "SELECT id, product_name, sku, barcode, unit, purchase_price, quantity, total
     FROM purchase_items
     WHERE purchase_id = ? AND shop_id = ?
     ORDER BY id ASC"
);

if (!$itemStmt) {
    http_response_code(500);
    exit('Unable to prepare purchase item query.');
}

$itemStmt->bind_param('ii', $purchaseId, $shop_id);
$itemStmt->execute();
$itemResult = $itemStmt->get_result();
$items = [];
$subtotal = 0.0;
$totalQty = 0.0;

while ($item = $itemResult->fetch_assoc()) {
    $item['purchase_price'] = (float)$item['purchase_price'];
    $item['quantity'] = (float)$item['quantity'];
    $item['total'] = (float)$item['total'];
    $items[] = $item;
    $subtotal += $item['total'];
    $totalQty += $item['quantity'];
}
$itemStmt->close();

$deliveryCharge = isset($purchase['delivery_charge']) ? (float)$purchase['delivery_charge'] : 0.0;
$grandTotal = (float)$purchase['grand_total'];
$paidAmount = (float)$purchase['paid_amount'];
$dueAmount = (float)$purchase['due_amount'];

$paymentMethod = $paidAmount > 0 ? 'Cash' : 'Due / Credit';
$paymentAccount = '';

// The purchase table does not store payment_method. Read it from the related
// asset transaction when available, while keeping a safe fallback.
try {
    $paymentStmt = $conn->prepare(
        "SELECT from_asset_type, from_asset_name
         FROM asset_transactions
         WHERE reference_type = 'purchase'
           AND reference_id = ?
           AND shop_id = ?
           AND movement_type = 'purchase_payment'
         ORDER BY id ASC
         LIMIT 1"
    );

    if ($paymentStmt) {
        $paymentStmt->bind_param('ii', $purchaseId, $shop_id);
        $paymentStmt->execute();
        $paymentRow = $paymentStmt->get_result()->fetch_assoc();
        $paymentStmt->close();

        if ($paymentRow) {
            $methodMap = [
                'cash'  => 'Cash',
                'bank'  => 'Bank',
                'bkash' => 'bKash',
                'nagad' => 'Nagad'
            ];
            $type = strtolower((string)$paymentRow['from_asset_type']);
            $paymentMethod = $methodMap[$type] ?? ucfirst($type);
            $paymentAccount = (string)($paymentRow['from_asset_name'] ?? '');
        }
    }
} catch (Throwable $e) {
    // Keep the fallback payment method. Invoice generation must not fail merely
    // because an older installation has no asset transaction table.
}

$createdAtRaw = !empty($purchase['created_at']) ? $purchase['created_at'] : date('Y-m-d H:i:s');
$createdTimestamp = strtotime($createdAtRaw) ?: time();
$invoiceCode = 'PUR-' . date('Ymd', $createdTimestamp) . '-' . str_pad((string)$purchaseId, 5, '0', STR_PAD_LEFT);
$supplierInvoiceNo = trim((string)($purchase['invoice_no'] ?? ''));
$createdBy = $_SESSION['user_name'] ?? $_SESSION['username'] ?? ('User #' . (int)$_SESSION['user_id']);

$logoUrl = '';
$logoCandidates = [
    ['file' => __DIR__ . '/../../uploads/logo.png', 'url' => '../../uploads/logo.png'],
    ['file' => __DIR__ . '/../../assets/images/logo.png', 'url' => '../../assets/images/logo.png'],
    ['file' => __DIR__ . '/../../assets/img/logo.png', 'url' => '../../assets/img/logo.png'],
    ['file' => __DIR__ . '/../../assets/logo.png', 'url' => '../../assets/logo.png'],
];
foreach ($logoCandidates as $candidate) {
    if (is_file($candidate['file'])) {
        $logoUrl = $candidate['url'];
        break;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Purchase Invoice <?= h($invoiceCode) ?></title>
    <style>
        :root {
            --ink: #111827;
            --muted: #4b5563;
            --paper: #ffffff;
            --page: #e9eef4;
            --line: #111827;
            --accent: #0f172a;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 12px;
            background: var(--page);
            color: var(--ink);
            font-family: Arial, Helvetica, sans-serif;
        }

        .toolbar {
            width: 80mm;
            max-width: 100%;
            margin: 0 auto 10px;
            display: flex;
            justify-content: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .toolbar button,
        .toolbar a {
            border: 0;
            border-radius: 4px;
            background: var(--accent);
            color: #fff;
            padding: 8px 12px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            box-shadow: 0 2px 4px rgba(15, 23, 42, .18);
        }

        .toolbar button:hover,
        .toolbar a:hover { opacity: .9; }
        .toolbar button:disabled { opacity: .65; cursor: wait; }

        .saved-note {
            width: 80mm;
            max-width: 100%;
            margin: 0 auto 8px;
            padding: 7px 9px;
            background: #dcfce7;
            border: 1px solid #86efac;
            color: #166534;
            border-radius: 5px;
            font-size: 11px;
            text-align: center;
        }

        .invoice {
            width: 80mm;
            max-width: 100%;
            min-height: 150mm;
            margin: 0 auto;
            padding: 3mm;
            background: var(--paper);
            border: 1px solid #111;
            box-shadow: 0 2px 8px rgba(15, 23, 42, .18);
            font-size: 9px;
            line-height: 1.3;
        }

        .header-grid {
            display: grid;
            grid-template-columns: 18mm 1fr 22mm;
            gap: 2mm;
            align-items: start;
        }

        .logo-box {
            width: 16mm;
            height: 16mm;
            border: 1px solid #111;
            border-radius: 50%;
            display: grid;
            place-items: center;
            overflow: hidden;
            font-size: 7px;
            text-align: center;
        }

        .logo-box img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 1mm;
        }

        .company {
            text-align: center;
            overflow-wrap: anywhere;
        }

        .company h1 {
            margin: 0 0 1mm;
            font-size: 16px;
            line-height: 1.05;
            font-family: "Noto Sans Bengali", Arial, sans-serif;
        }

        .company div { margin-bottom: .3mm; }
        .company strong { font-weight: 700; }

        .barcode-box { text-align: center; }

        .barcode-bars {
            height: 14mm;
            width: 100%;
            border-left: 1px solid #111;
            border-right: 1px solid #111;
            background:
                repeating-linear-gradient(
                    90deg,
                    #111 0,
                    #111 .35mm,
                    transparent .35mm,
                    transparent .75mm,
                    #111 .75mm,
                    #111 1.25mm,
                    transparent 1.25mm,
                    transparent 1.6mm,
                    #111 1.6mm,
                    #111 1.8mm,
                    transparent 1.8mm,
                    transparent 2.35mm
                );
        }

        .barcode-code {
            margin-top: .5mm;
            font-size: 6.5px;
            letter-spacing: -.15px;
            overflow-wrap: anywhere;
        }

        .policy {
            margin: 2mm 0 1.5mm;
            padding: 1mm 0;
            border-top: 1px dashed #555;
            border-bottom: 1px dashed #555;
            text-align: center;
            font-size: 7px;
            line-height: 1.4;
        }

        .invoice-title {
            width: 35mm;
            margin: 0 auto 1.5mm;
            padding: .7mm 1mm;
            background: #111827;
            color: #fff;
            text-align: center;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: .3px;
        }

        .meta-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2mm;
            margin-bottom: 2mm;
        }

        .meta-table {
            width: 100%;
            border-collapse: collapse;
        }

        .meta-table td {
            padding: .35mm 0;
            vertical-align: top;
            overflow-wrap: anywhere;
        }

        .meta-table td:first-child {
            width: 18mm;
            font-weight: 700;
        }

        .items {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin-top: 1mm;
        }

        .items th,
        .items td {
            border: 1px solid #111;
            padding: 1mm .7mm;
            vertical-align: top;
            overflow-wrap: anywhere;
        }

        .items th {
            background: #f3f4f6;
            text-align: center;
            font-size: 7.5px;
            line-height: 1.1;
        }

        .items td { font-size: 7.5px; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .item-name { font-weight: 700; }
        .item-extra { margin-top: .4mm; color: #4b5563; font-size: 6.5px; }

        .summary-grid {
            display: grid;
            grid-template-columns: 1fr 1.12fr;
            border: 1px solid #111;
            border-top: 0;
        }

        .item-count {
            padding: 1.2mm;
            font-weight: 700;
            border-right: 1px solid #111;
        }

        .totals {
            width: 100%;
            border-collapse: collapse;
        }

        .totals td {
            padding: .35mm 1mm;
            font-size: 7.5px;
        }

        .totals td:last-child {
            text-align: right;
            font-weight: 700;
        }

        .totals tr:last-child td {
            border-top: 1px solid #111;
            padding-top: .7mm;
            font-weight: 800;
        }

        .in-words {
            margin: 2mm 0 8mm;
            font-size: 7px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .signature-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8mm;
            margin-top: 8mm;
        }

        .signature {
            border-top: 1px solid #111;
            padding-top: 1mm;
            text-align: center;
            font-size: 7px;
        }

        .footer-line {
            margin-top: 4mm;
            border-top: 1px dashed #555;
            padding-top: 2mm;
            text-align: center;
            font-size: 8px;
            font-weight: 800;
            letter-spacing: .5px;
        }

        @media (max-width: 380px) {
            body { padding: 4px; }
            .invoice { padding: 2mm; }
            .company h1 { font-size: 14px; }
        }

        @media print {
            @page { size: 80mm auto; margin: 0; }
            html, body { width: 80mm; background: #fff; }
            body { margin: 0; padding: 0; }
            .toolbar, .saved-note { display: none !important; }
            .invoice {
                width: 80mm;
                max-width: none;
                min-height: 0;
                margin: 0;
                border: 0;
                box-shadow: none;
                page-break-after: avoid;
            }
        }
    
/* Receipt style refinement */
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700;800;900&display=swap');

body, html, .invoice, .receipt-shell, .receipt-wrap {
    font-family: "Noto Sans", Arial, sans-serif !important;
    font-weight: 600;
    letter-spacing: .1px;
}
.invoice, .receipt-shell, .receipt-wrap {
    padding: 4mm 3.5mm 5mm !important;
    border: 0 !important;
    box-shadow: none !important;
}
.shop-title-bn, .shop-title-en, .brand-name, h1, h2, h3 {
    font-weight: 900 !important;
}
.shop-info, .customer-info, .details, .item-name {
    font-weight: 700 !important;
}
table, th, td {
    font-weight: 700;
}
.total, .net, .grand-total, .payable, .due, .amount {
    font-weight: 900 !important;
    font-size: 1.08em;
}
hr, .divider {
    border-top: 1px dashed #000 !important;
}
@media print {
    body { background:#fff !important; padding:0 !important; }
}
</style>
</head>
<body>
    <div class="toolbar">
        <button type="button" onclick="window.print()">🖨 Print Invoice</button>
        <button type="button" id="pdfButton" onclick="downloadInvoicePDF()">PDF Invoice</button>
        <a href="add_purchase.php">＋ New Purchase</a>
    </div>

    <?php if (isset($_GET['saved']) && $_GET['saved'] === '1'): ?>
        <div class="saved-note">Purchase saved successfully. Your invoice is ready.</div>
    <?php endif; ?>

    <main class="invoice" id="invoiceArea">
        <section class="header-grid">
            <div class="logo-box">
                <?php if ($logoUrl !== ''): ?>
                    <img src="<?= h($logoUrl) ?>" alt="Logo">
                <?php else: ?>
                    LOGO
                <?php endif; ?>
            </div>

            <div class="company">
                <h1><?= h($company['name']) ?></h1>
                <div><?= nl2br(h($company['address'])) ?></div>
                <div><strong>Mobile:</strong> <?= h($company['mobile']) ?></div>
                <?php if ($company['hotline'] !== ''): ?>
                    <div><strong>Hotline:</strong> <?= h($company['hotline']) ?></div>
                <?php endif; ?>
                <div><strong>Email:</strong> <?= h($company['email']) ?></div>
                <?php if ($company['trade_license'] !== ''): ?>
                    <div><strong>Trade Licence:</strong> <?= h($company['trade_license']) ?></div>
                <?php endif; ?>
            </div>

            <div class="barcode-box">
                <div class="barcode-bars" aria-label="Invoice barcode"></div>
                <div class="barcode-code"><?= h($invoiceCode) ?></div>
            </div>
        </section>

        <div class="policy">
            Please preserve this invoice for future reference.<br>
            Purchased goods are subject to the supplier agreement.
        </div>

        <div class="invoice-title">PURCHASE INVOICE</div>

        <section class="meta-grid">
            <table class="meta-table">
                <tr>
                    <td>Supplier</td>
                    <td><?= h($purchase['supplier_name'] ?: 'N/A') ?></td>
                </tr>
                <tr>
                    <td>Mobile</td>
                    <td><?= h($purchase['supplier_phone'] ?: 'N/A') ?></td>
                </tr>
                <tr>
                    <td>Address</td>
                    <td><?= nl2br(h($purchase['supplier_address'] ?: 'N/A')) ?></td>
                </tr>
            </table>

            <table class="meta-table">
                <tr>
                    <td>Invoice</td>
                    <td><?= h($invoiceCode) ?></td>
                </tr>
                <tr>
                    <td>Supplier Inv.</td>
                    <td><?= h($supplierInvoiceNo !== '' ? $supplierInvoiceNo : 'N/A') ?></td>
                </tr>
                <tr>
                    <td>Date</td>
                    <td><?= h(date('d/m/Y', $createdTimestamp)) ?></td>
                </tr>
                <tr>
                    <td>Created By</td>
                    <td><?= h($createdBy) ?></td>
                </tr>
                <tr>
                    <td>Payment</td>
                    <td>
                        <?= h($paymentMethod) ?>
                        <?php if ($paymentAccount !== ''): ?>
                            <br><small><?= h($paymentAccount) ?></small>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </section>

        <table class="items">
            <thead>
                <tr>
                    <th style="width: 7%;">SL</th>
                    <th style="width: 34%;">Item Name</th>
                    <th style="width: 16%;">Unit Price</th>
                    <th style="width: 11%;">Qty</th>
                    <th style="width: 13%;">Discount</th>
                    <th style="width: 19%;">Sub Total</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$items): ?>
                    <tr>
                        <td colspan="6" class="text-center">No purchase items found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($items as $index => $item): ?>
                        <tr>
                            <td class="text-center"><?= $index + 1 ?></td>
                            <td>
                                <div class="item-name"><?= h($item['product_name']) ?></div>
                                <?php if (!empty($item['sku'])): ?>
                                    <div class="item-extra">SKU: <?= h($item['sku']) ?></div>
                                <?php endif; ?>
                                <?php if (!empty($item['barcode'])): ?>
                                    <div class="item-extra">Barcode: <?= h($item['barcode']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-right"><?= money($item['purchase_price']) ?></td>
                            <td class="text-center">
                                <?= h(rtrim(rtrim(number_format($item['quantity'], 2, '.', ''), '0'), '.')) ?>
                                <?php if (!empty($item['unit'])): ?>
                                    <br><small><?= h($item['unit']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td class="text-right">0.00</td>
                            <td class="text-right"><?= money($item['total']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <section class="summary-grid">
            <div class="item-count">
                Total Item: <?= count($items) ?><br>
                Total Qty: <?= h(rtrim(rtrim(number_format($totalQty, 2, '.', ''), '0'), '.')) ?>
            </div>

            <table class="totals">
                <tr><td>Sub Total</td><td><?= money($subtotal) ?></td></tr>
                <tr><td>Discount</td><td>0.00</td></tr>
                <tr><td>Delivery</td><td><?= money($deliveryCharge) ?></td></tr>
                <tr><td>Grand Total</td><td><?= money($grandTotal) ?></td></tr>
                <tr><td>Paid Amount</td><td><?= money($paidAmount) ?></td></tr>
                <tr><td>Current Due</td><td><?= money($dueAmount) ?></td></tr>
                <tr><td>Total Due</td><td><?= money($dueAmount) ?></td></tr>
            </table>
        </section>

        <div class="in-words">IN WORDS: <?= h(numberToWordsBDT($grandTotal)) ?></div>

        <section class="signature-grid">
            <div class="signature">Supplier Signature</div>
            <div class="signature">Authorized Signature</div>
        </section>

        <div class="footer-line"><?= h($company['footer']) ?></div>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
        async function downloadInvoicePDF() {
            const button = document.getElementById('pdfButton');
            const invoice = document.getElementById('invoiceArea');
            const originalText = button.textContent;

            if (!window.html2canvas || !window.jspdf || !window.jspdf.jsPDF) {
                alert('PDF library could not load. Please use Print Invoice and choose Save as PDF.');
                return;
            }

            button.disabled = true;
            button.textContent = 'Generating PDF...';

            try {
                const canvas = await window.html2canvas(invoice, {
                    scale: 3,
                    useCORS: true,
                    backgroundColor: '#ffffff',
                    logging: false
                });

                const imageData = canvas.toDataURL('image/jpeg', 0.98);
                const pdfWidth = 80;
                const pdfHeight = Math.max(120, (canvas.height * pdfWidth) / canvas.width);
                const jsPDF = window.jspdf.jsPDF;
                const pdf = new jsPDF({
                    orientation: 'portrait',
                    unit: 'mm',
                    format: [pdfWidth, pdfHeight],
                    compress: true
                });

                pdf.addImage(imageData, 'JPEG', 0, 0, pdfWidth, pdfHeight, undefined, 'FAST');
                pdf.save(<?= json_encode($invoiceCode . '.pdf') ?>);
            } catch (error) {
                console.error(error);
                alert('PDF generation failed. Please use Print Invoice and choose Save as PDF.');
            } finally {
                button.disabled = false;
                button.textContent = originalText;
            }
        }
    </script>
</body>
</html>
