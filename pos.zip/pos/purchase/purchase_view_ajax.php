<?php
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(true);
$shop_id = tenantShopId();

// purchase_view_ajax.php
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

include "../../config/db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid purchase ID']);
    exit();
}

// Get purchase details
$stmt = $conn->prepare("
    SELECT p.*, s.supplier_name 
    FROM purchases p
    INNER JOIN suppliers s ON s.id = p.supplier_id
    WHERE p.id = ? AND s.shop_id = ?
");
$stmt->bind_param("ii", $id, $shop_id);
$stmt->execute();
$result = $stmt->get_result();
$purchase = $result->fetch_assoc();

if (!$purchase) {
    echo json_encode(['success' => false, 'message' => 'Purchase not found']);
    exit();
}

// Get purchase items
$stmt = $conn->prepare("
    SELECT product_name, quantity, unit, purchase_price, total 
    FROM purchase_items 
    WHERE purchase_id = ? AND shop_id = ?
");
$stmt->bind_param("ii", $id, $shop_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$due = $purchase['grand_total'] - $purchase['paid_amount'];

echo json_encode([
    'success' => true,
    'invoice_no' => $purchase['invoice_no'],
    'date' => date('d-m-Y', strtotime($purchase['created_at'])),
    'supplier_name' => $purchase['supplier_name'] ?? 'Unknown',
    'grand_total' => number_format($purchase['grand_total'], 2),
    'paid_amount' => number_format($purchase['paid_amount'], 2),
    'due' => number_format($due, 2),
    'status' => $due <= 0 ? '<span class="badge-paid">Paid</span>' : '<span class="badge-due">Due</span>',
    'items_count' => count($items),
    'items' => $items
]);