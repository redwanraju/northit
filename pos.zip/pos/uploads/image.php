<?php
// image.php?file=abc.jpg&folder=products

$folder = preg_replace('/[^a-z]/', '', $_GET['folder'] ?? 'products');
$file = preg_replace('/[^a-zA-Z0-9._-]/', '', $_GET['file'] ?? '');

$path = __DIR__ . '/uploads/' . $folder . '/' . $file;

$allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

if(!in_array($ext, $allowed_ext) || !file_exists($path)){
    header('HTTP/1.1 404 Not Found');
    exit;
}

$mime = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp'];
header('Content-Type: ' . ($mime[$ext] ?? 'image/jpeg'));
readfile($path);
?>