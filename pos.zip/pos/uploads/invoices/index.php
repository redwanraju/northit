<?php
// uploads/invoices/index.php
header('HTTP/1.1 403 Forbidden');
exit('Access Denied');
?>