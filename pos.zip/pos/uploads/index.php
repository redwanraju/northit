<?php
// uploads/index.php - Directory access block
header('HTTP/1.1 403 Forbidden');
exit('Access Denied');
?>