<?php
// uploads/upload_handler.php - Secure image delivery

// 1. Block direct PHP execution
if(basename($_SERVER['PHP_SELF']) === basename(__FILE__)){
    header('HTTP/1.1 403 Forbidden');
    exit('Direct access denied');
}

// 2. Function to serve image securely
function serveImage($filename, $folder = 'products'){
    $allowed_folders = ['products', 'invoices', 'customers'];
    if(!in_array($folder, $allowed_folders)){
        header('HTTP/1.1 403 Forbidden');
        exit('Invalid folder');
    }
    
    $filepath = __DIR__ . '/' . $folder . '/' . basename($filename);
    
    // Security: only allow image files
    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
    
    if(!in_array($ext, $allowed_ext)){
        header('HTTP/1.1 403 Forbidden');
        exit('Invalid file type');
    }
    
    if(!file_exists($filepath)){
        header('HTTP/1.1 404 Not Found');
        exit('File not found');
    }
    
    // Serve with correct MIME type
    $mime_types = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp'
    ];
    
    header('Content-Type: ' . ($mime_types[$ext] ?? 'application/octet-stream'));
    header('Content-Length: ' . filesize($filepath));
    readfile($filepath);
    exit;
}
?>