<?php
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(false);

/**
 * ==========================================
 *  Purchase Invoice Print Page
 *  File: /pos/suppliers/print_invoice.php
 * ==========================================
 */

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);


// Check Login
if(!isset($_SESSION['user_id'])){
    die("<div style='text-align:center;padding:50px;'>
        <h2 style='color:#ef4444;'>❌ Access Denied</h2>
        <p>Please login to view this page.</p>
        <a href='../login.php' style='color:#2563eb;'>← Login</a>
    </div>");
}

// Include Database Connection
include "../../config/db.php";

$shop_id = tenantShopId();
$invoice_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($invoice_id <= 0) {
    die("<div style='text-align:center;padding:50px;'>
        <h2 style='color:#ef4444;'>❌ Invalid Invoice ID</h2>
        <p>Please provide a valid invoice ID.</p>
        <a href='purchase_entry.php' style='color:#2563eb;'>← Back to Purchase List</a>
    </div>");
}

// ============================================================
// FETCH PURCHASE MASTER DATA (with Shop ID check)
// ============================================================
$stmt = $conn->prepare("
    SELECT 
        p.*,
        s.supplier_name,
        s.phone AS supplier_phone,
        s.email AS supplier_email,
        s.address AS supplier_address,
        NULL AS created_by_name
    FROM purchases p
    INNER JOIN suppliers s ON p.supplier_id = s.id
    WHERE p.id = ? AND s.shop_id = ?
");
$stmt->bind_param("ii", $invoice_id, $shop_id);
$stmt->execute();
$result = $stmt->get_result();
$purchase = $result->fetch_assoc();
$stmt->close();

if (!$purchase) {
    die("<div style='text-align:center;padding:50px;'>
        <h2 style='color:#ef4444;'>❌ Invoice Not Found</h2>
        <p>The requested invoice does not exist or you don't have permission.</p>
        <a href='purchase_entry.php' style='color:#2563eb;'>← Back to Purchase List</a>
    </div>");
}

// ============================================================
// FETCH PURCHASE ITEMS
// ============================================================
$stmt_items = $conn->prepare("
    SELECT 
        pi.*,
        COALESCE(pr.product_name, pi.product_name) AS product_name,
        COALESCE(pr.sku, pi.sku) AS product_code,
        COALESCE(pr.unit, pi.unit) AS unit,
        c.category_name,
        b.brand_name
    FROM purchase_items pi
    LEFT JOIN products pr ON pi.product_id = pr.id AND pr.shop_id = pi.shop_id
    LEFT JOIN categories c ON pr.category_id = c.id AND c.shop_id = pi.shop_id
    LEFT JOIN brands b ON pr.brand_id = b.id AND b.shop_id = pi.shop_id
    WHERE pi.purchase_id = ? AND pi.shop_id = ?
");
$stmt_items->bind_param("ii", $invoice_id, $shop_id);
$stmt_items->execute();
$items_result = $stmt_items->get_result();
$purchase_items = [];
while ($row = $items_result->fetch_assoc()) {
    $purchase_items[] = $row;
}
$stmt_items->close();

// ============================================================
// FETCH PAYMENT HISTORY (from supplier_payments)
// ============================================================
$stmt_pay = $conn->prepare("
    SELECT 
        sp.*,
        NULL AS paid_by_name
    FROM supplier_payments sp
    INNER JOIN suppliers s ON s.id = sp.supplier_id
    WHERE sp.purchase_id = ? AND s.shop_id = ?
    ORDER BY sp.payment_date DESC
");
$stmt_pay->bind_param("ii", $invoice_id, $shop_id);
$stmt_pay->execute();
$pay_result = $stmt_pay->get_result();
$payments = [];
while ($row = $pay_result->fetch_assoc()) {
    $payments[] = $row;
}
$stmt_pay->close();

// ============================================================
// FETCH SHOP/COMPANY SETTINGS
// ============================================================
$shop_settings = [
    'shop_name' => 'Smart ERP',
    'shop_tagline' => 'Business Management System',
    'shop_address' => 'Dhaka, Bangladesh',
    'shop_phone' => '',
    'shop_email' => '',
    'shop_vat' => '',
    'currency_symbol' => '৳'
];
$settings_stmt = $conn->prepare("SELECT shop_name, phone, address FROM shops WHERE id = ? LIMIT 1");
$settings_stmt->bind_param("i", $shop_id);
$settings_stmt->execute();
$shop_row = $settings_stmt->get_result()->fetch_assoc();
if ($shop_row) {
    $shop_settings['shop_name'] = $shop_row['shop_name'] ?: $shop_settings['shop_name'];
    $shop_settings['shop_phone'] = $shop_row['phone'] ?: '';
    $shop_settings['shop_address'] = $shop_row['address'] ?: $shop_settings['shop_address'];
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================
function safe($val, $default = '') {
    return htmlspecialchars($val ?? $default, ENT_QUOTES, 'UTF-8');
}

function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') return 'N/A';
    return date('d M Y', strtotime($date));
}

function formatDateTime($datetime) {
    if (empty($datetime)) return 'N/A';
    return date('d M Y, h:i A', strtotime($datetime));
}

function formatMoney($amount) {
    return number_format($amount ?? 0, 2);
}

// ============================================================
// CALCULATE TOTALS
// ============================================================
$subtotal = 0;
$total_items = count($purchase_items);
foreach ($purchase_items as $item) {
    $subtotal += ($item['quantity'] * $item['unit_price']);
}

$discount = $purchase['discount'] ?? 0;
$tax = $purchase['tax'] ?? 0;
$shipping = $purchase['shipping_cost'] ?? 0;
$grand_total = $purchase['grand_total'] ?? ($subtotal - $discount + $tax + $shipping);
$paid_amount = $purchase['paid_amount'] ?? 0;
$due_amount = $purchase['due_amount'] ?? ($grand_total - $paid_amount);

// Payment Status
if ($due_amount <= 0) {
    $payment_status = 'Paid';
    $status_class = 'paid';
} elseif ($paid_amount > 0) {
    $payment_status = 'Partial';
    $status_class = 'partial';
} else {
    $payment_status = 'Unpaid';
    $status_class = 'unpaid';
}

$currency = $shop_settings['currency_symbol'] ?? '৳';

// Check if image exists
$has_invoice_image = !empty($purchase['invoice_image']) && file_exists("../../uploads/invoices/" . $purchase['invoice_image']);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Invoice #<?= safe($purchase['invoice_no']) ?> | <?= safe($shop_settings['shop_name'] ?? 'Smart ERP') ?></title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css"/>

    <style>
        :root {
            --primary: #2563eb;
            --secondary: #7c3aed;
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
            --dark: #1e293b;
            --light: #f8fafc;
            --border: #e2e8f0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f1f5f9;
            color: #334155;
            line-height: 1.6;
        }

        .invoice-wrapper {
            max-width: 900px;
            margin: 30px auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .invoice-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: #fff;
            padding: 30px 35px;
            position: relative;
        }

        .invoice-header::after {
            content: '';
            position: absolute;
            bottom: -20px;
            left: 0;
            right: 0;
            height: 40px;
            background: #fff;
            border-radius: 50% 50% 0 0;
        }

        .shop-name { font-size: 24px; font-weight: 800; margin-bottom: 2px; }
        .shop-tagline { font-size: 12px; opacity: 0.9; letter-spacing: 0.5px; }

        .invoice-title {
            font-size: 30px;
            font-weight: 900;
            opacity: 0.12;
            position: absolute;
            right: 35px;
            top: 25px;
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        .invoice-info-bar {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 25px 35px 5px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .info-group { flex: 1; min-width: 150px; }
        .info-label { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #94a3b8; font-weight: 600; margin-bottom: 4px; }
        .info-value { font-size: 14px; color: #1e293b; font-weight: 600; }
        .info-value.large { font-size: 20px; font-weight: 800; }

        .status-badge {
            display: inline-block;
            padding: 4px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-paid { background: #dcfce7; color: #16a34a; }
        .status-partial { background: #fef3c7; color: #d97706; }
        .status-unpaid { background: #fee2e2; color: #dc2626; }

        .section-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--border), transparent);
            margin: 0 35px;
        }

        .parties-section {
            display: flex;
            padding: 20px 35px;
            gap: 30px;
            flex-wrap: wrap;
        }

        .party-box {
            flex: 1;
            min-width: 220px;
            background: var(--light);
            border-radius: 10px;
            padding: 16px 20px;
            border-left: 3px solid var(--primary);
        }
        .party-box.supplier { border-left-color: var(--secondary); }

        .party-title {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #94a3b8;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .party-name { font-size: 16px; font-weight: 700; color: var(--dark); margin-bottom: 6px; }
        .party-detail {
            font-size: 12px;
            color: #64748b;
            margin-bottom: 3px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .party-detail i { width: 14px; color: var(--primary); font-size: 11px; }

        .items-section { padding: 20px 35px; }
        .section-title { font-size: 14px; font-weight: 700; color: var(--dark); margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        .section-title i { color: var(--primary); }

        .items-table { width: 100%; border-collapse: separate; border-spacing: 0; }
        .items-table thead th {
            background: var(--dark);
            color: #fff;
            padding: 10px 14px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
            text-align: left;
        }
        .items-table thead th:first-child { border-radius: 8px 0 0 8px; }
        .items-table thead th:last-child { border-radius: 0 8px 8px 0; text-align: right; }

        .items-table tbody td { padding: 10px 14px; font-size: 13px; color: #475569; border-bottom: 1px solid #f1f5f9; }
        .items-table tbody td:last-child { text-align: right; font-weight: 600; color: var(--dark); }
        .items-table tbody tr:hover { background: #f8fafc; }

        .item-name { font-weight: 600; color: var(--dark); }
        .item-meta { font-size: 10px; color: #94a3b8; margin-top: 2px; }

        .summary-section { padding: 10px 35px 25px; display: flex; justify-content: flex-end; }
        .summary-box { width: 280px; background: var(--light); border-radius: 10px; padding: 16px 20px; }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 13px;
            color: #64748b;
        }
        .summary-row.total {
            border-top: 2px solid var(--border);
            margin-top: 6px;
            padding-top: 10px;
            font-size: 16px;
            font-weight: 800;
            color: var(--dark);
        }
        .summary-row.due { color: var(--danger); font-weight: 700; }
        .summary-row.paid { color: var(--success); font-weight: 700; }

        .payment-section { padding: 0 35px 25px; }
        .payment-table { width: 100%; border-collapse: collapse; }
        .payment-table th {
            background: #f1f5f9;
            padding: 8px 12px;
            font-size: 10px;
            text-transform: uppercase;
            color: #64748b;
            font-weight: 600;
            text-align: left;
        }
        .payment-table td { padding: 8px 12px; font-size: 12px; color: #475569; border-bottom: 1px solid #f1f5f9; }

        .invoice-footer {
            background: var(--dark);
            color: #94a3b8;
            padding: 20px 35px;
            text-align: center;
            font-size: 11px;
        }
        .invoice-footer p { margin: 3px 0; }
        .footer-brand { color: #fff; font-weight: 700; font-size: 13px; }

        /* Invoice Image */
        .invoice-image-section { padding: 0 35px 20px; }
        .invoice-image-section img { max-width: 100%; max-height: 200px; border-radius: 8px; border: 1px solid var(--border); }

        .action-bar {
            position: fixed;
            bottom: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }

        .btn-action {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            transition: all 0.3s ease;
        }
        .btn-action:hover { transform: translateY(-2px); box-shadow: 0 15px 40px rgba(0,0,0,0.18); }

        .btn-print { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: #fff; }
        .btn-pdf { background: var(--danger); color: #fff; }
        .btn-close { background: #fff; color: var(--dark); border: 1px solid var(--border); }

        @media print {
            @page { size: A4; margin: 0; }
            body { background: #fff; margin: 0; padding: 0; }
            .invoice-wrapper { margin: 0; box-shadow: none; border-radius: 0; max-width: 100%; }
            .action-bar, .no-print { display: none !important; }
            .invoice-header { padding: 20px 25px; }
            .invoice-header::after { display: none; }
            .invoice-info-bar, .parties-section, .items-section, .summary-section, .payment-section { padding-left: 25px; padding-right: 25px; }
            .section-divider { margin: 0 25px; }
            .items-table thead th { background: #1e293b !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .invoice-header { background: linear-gradient(135deg, #2563eb, #7c3aed) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .party-box { background: #f8fafc !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .summary-box { background: #f8fafc !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .invoice-footer { background: #1e293b !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }

        @media (max-width: 768px) {
            .invoice-wrapper { margin: 10px; border-radius: 10px; }
            .invoice-header { padding: 20px 15px; }
            .invoice-info-bar, .parties-section, .items-section, .summary-section, .payment-section { padding-left: 15px; padding-right: 15px; }
            .section-divider { margin: 0 15px; }
            .action-bar { bottom: 10px; right: 10px; left: 10px; justify-content: center; flex-wrap: wrap; }
            .btn-action { padding: 8px 14px; font-size: 11px; }
            .items-table { font-size: 11px; }
            .items-table thead th, .items-table tbody td { padding: 8px 6px; }
            .summary-box { width: 100%; }
        }
    </style>
</head>
<body>

<!-- ================= INVOICE WRAPPER ================= -->
<div class="invoice-wrapper">

    <!-- HEADER -->
    <div class="invoice-header">
        <div class="invoice-title">INVOICE</div>
        <div class="shop-name"><?= safe($shop_settings['shop_name'] ?? 'Smart ERP') ?></div>
        <div class="shop-tagline"><?= safe($shop_settings['shop_tagline'] ?? 'Business Management System') ?></div>
    </div>

    <!-- INFO BAR -->
    <div class="invoice-info-bar">
        <div class="info-group">
            <div class="info-label">Invoice Number</div>
            <div class="info-value large">#<?= safe($purchase['invoice_no']) ?></div>
        </div>
        <div class="info-group">
            <div class="info-label">Purchase Date</div>
            <div class="info-value"><?= formatDate($purchase['purchase_date'] ?? $purchase['created_at']) ?></div>
        </div>
        <div class="info-group">
            <div class="info-label">Payment Status</div>
            <div class="info-value">
                <span class="status-badge status-<?= $status_class ?>">
                    <?= $payment_status ?>
                </span>
            </div>
        </div>
    </div>

    <div class="section-divider"></div>

    <!-- PARTIES -->
    <div class="parties-section">
        <div class="party-box">
            <div class="party-title"><i class="fas fa-store"></i> From (Seller)</div>
            <div class="party-name"><?= safe($shop_settings['shop_name'] ?? 'Smart ERP') ?></div>
            <div class="party-detail">
                <i class="fas fa-location-dot"></i>
                <?= safe($shop_settings['shop_address'] ?? 'N/A') ?>
            </div>
            <div class="party-detail">
                <i class="fas fa-phone"></i>
                <?= safe($shop_settings['shop_phone'] ?? 'N/A') ?>
            </div>
            <div class="party-detail">
                <i class="fas fa-envelope"></i>
                <?= safe($shop_settings['shop_email'] ?? 'N/A') ?>
            </div>
        </div>

        <div class="party-box supplier">
            <div class="party-title"><i class="fas fa-truck"></i> To (Supplier)</div>
            <div class="party-name"><?= safe($purchase['supplier_name'] ?? 'Unknown Supplier') ?></div>
            <div class="party-detail">
                <i class="fas fa-phone"></i>
                <?= safe($purchase['supplier_phone'] ?? 'N/A') ?>
            </div>
            <div class="party-detail">
                <i class="fas fa-envelope"></i>
                <?= safe($purchase['supplier_email'] ?? 'N/A') ?>
            </div>
            <div class="party-detail">
                <i class="fas fa-location-dot"></i>
                <?= safe($purchase['supplier_address'] ?? 'N/A') ?>
            </div>
        </div>
    </div>

    <div class="section-divider"></div>

    <!-- ITEMS -->
    <div class="items-section">
        <div class="section-title">
            <i class="fas fa-box-open"></i>
            Purchase Items (<?= $total_items ?> items)
        </div>
        <table class="items-table">
            <thead>
                <tr>
                    <th style="width:5%;">#</th>
                    <th style="width:38%;">Product</th>
                    <th style="width:12%;" class="text-center">Code</th>
                    <th style="width:10%;" class="text-center">Qty</th>
                    <th style="width:12%;" class="text-right">Price</th>
                    <th style="width:10%;" class="text-right">Disc.</th>
                    <th style="width:13%;" class="text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($purchase_items)): 
                    $sl = 1;
                    foreach ($purchase_items as $item): 
                        $item_total = ($item['quantity'] * $item['unit_price']) - ($item['discount'] ?? 0);
                ?>
                <tr>
                    <td><?= $sl++ ?></td>
                    <td>
                        <div class="item-name"><?= safe($item['product_name'] ?? 'Unknown') ?></div>
                        <div class="item-meta">
                            <?= safe($item['category_name'] ?? '') ?>
                            <?= !empty($item['brand_name']) ? '• ' . safe($item['brand_name']) : '' ?>
                        </div>
                    </td>
                    <td class="text-center"><?= safe($item['product_code'] ?? 'N/A') ?></td>
                    <td class="text-center">
                        <?= formatMoney($item['quantity']) ?>
                        <small style="color:#94a3b8;"><?= safe($item['unit'] ?? 'pcs') ?></small>
                    </td>
                    <td class="text-right"><?= $currency ?> <?= formatMoney($item['unit_price']) ?></td>
                    <td class="text-right">
                        <?= ($item['discount'] ?? 0) > 0 ? $currency . ' ' . formatMoney($item['discount']) : '-' ?>
                    </td>
                    <td class="text-right"><?= $currency ?> <?= formatMoney($item_total) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center" style="padding:30px; color:#94a3b8;">
                        <i class="fas fa-inbox" style="font-size:24px; display:block; margin-bottom:8px;"></i>
                        No items found
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- SUMMARY -->
    <div class="summary-section">
        <div class="summary-box">
            <div class="summary-row"><span>Subtotal</span><span><?= $currency ?> <?= formatMoney($subtotal) ?></span></div>
            <?php if ($discount > 0): ?>
            <div class="summary-row"><span>Discount</span><span style="color:var(--danger);">- <?= $currency ?> <?= formatMoney($discount) ?></span></div>
            <?php endif; ?>
            <?php if ($tax > 0): ?>
            <div class="summary-row"><span>Tax/VAT</span><span>+ <?= $currency ?> <?= formatMoney($tax) ?></span></div>
            <?php endif; ?>
            <?php if ($shipping > 0): ?>
            <div class="summary-row"><span>Shipping</span><span>+ <?= $currency ?> <?= formatMoney($shipping) ?></span></div>
            <?php endif; ?>
            <div class="summary-row total">
                <span>Grand Total</span>
                <span><?= $currency ?> <?= formatMoney($grand_total) ?></span>
            </div>
            <div class="summary-row paid">
                <span>Paid Amount</span>
                <span><?= $currency ?> <?= formatMoney($paid_amount) ?></span>
            </div>
            <?php if ($due_amount > 0): ?>
            <div class="summary-row due">
                <span>Due Amount</span>
                <span><?= $currency ?> <?= formatMoney($due_amount) ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- INVOICE IMAGE -->
    <?php if($has_invoice_image): ?>
    <div class="invoice-image-section">
        <div class="section-title"><i class="fas fa-image"></i> Invoice Image</div>
        <img src="../../uploads/invoices/<?= safe($purchase['invoice_image']) ?>" alt="Invoice Image" loading="lazy">
    </div>
    <?php endif; ?>

    <!-- PAYMENTS -->
    <?php if(!empty($payments)): ?>
    <div class="payment-section">
        <div class="section-title"><i class="fas fa-clock-rotate-left"></i> Payment History</div>
        <table class="payment-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Method</th>
                    <th>Reference</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $psl = 1; foreach ($payments as $pay): ?>
                <tr>
                    <td><?= $psl++ ?></td>
                    <td><?= formatDateTime($pay['payment_date']) ?></td>
                    <td><span class="badge bg-<?= $pay['payment_method'] == 'Cash' ? 'success' : 'primary' ?>"><?= safe($pay['payment_method'] ?? 'Cash') ?></span></td>
                    <td><?= safe($pay['reference_no'] ?? 'N/A') ?></td>
                    <td style="font-weight:700;color:var(--success);"><?= $currency ?> <?= formatMoney($pay['payment_amount']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- NOTES -->
    <?php if(!empty($purchase['notes'])): ?>
    <div class="items-section" style="padding-top:0;">
        <div class="section-title"><i class="fas fa-sticky-note"></i> Notes</div>
        <div style="background:#fefce8; border-left:3px solid #eab308; padding:12px 16px; border-radius:0 6px 6px 0; font-size:12px; color:#854d0e;">
            <?= nl2br(safe($purchase['notes'])) ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- FOOTER -->
    <div class="invoice-footer">
        <p class="footer-brand"><?= safe($shop_settings['shop_name'] ?? 'Smart ERP') ?></p>
        <p><?= safe($shop_settings['shop_address'] ?? '') ?></p>
        <p>Phone: <?= safe($shop_settings['shop_phone'] ?? '') ?> | Email: <?= safe($shop_settings['shop_email'] ?? '') ?></p>
        <p style="margin-top:8px; font-size:10px;">
            <i class="fas fa-shield-halved"></i> Computer-generated invoice. No signature required.
        </p>
        <p style="font-size:9px; opacity:0.6;">
            Printed: <?= date('d M Y, h:i A') ?> | ID: #<?= $invoice_id ?>
        </p>
    </div>

</div>

<!-- ACTIONS -->
<div class="action-bar no-print">
    <button class="btn-action btn-print" onclick="window.print()">
        <i class="fas fa-print"></i> Print
    </button>
    <button class="btn-action btn-pdf" onclick="generatePDF()">
        <i class="fas fa-file-pdf"></i> PDF
    </button>
    <button class="btn-action btn-close" onclick="window.close()">
        <i class="fas fa-xmark"></i> Close
    </button>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
function generatePDF() {
    const originalTitle = document.title;
    document.title = 'Purchase_Invoice_<?= safe($purchase['invoice_no']) ?>';
    window.print();
    setTimeout(() => { document.title = originalTitle; }, 1000);
}

document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        window.print();
    }
    if (e.key === 'Escape') {
        window.close();
    }
});
</script>

</body>
</html>