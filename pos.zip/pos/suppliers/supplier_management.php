<?php
require_once dirname(__DIR__) . '/tenant_guard.php';
requireTenantSession(false);

// ============================================================
// Supplier Management - Professional CRUD + Ledger + Payment
// File: supplier_management.php
// Safety: shop_id scoped, CSRF protected, prepared statements,
//         modal CRUD, soft delete, supplier payment with asset
//         balance update + asset_transactions history.
// ============================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

include "../../config/db.php";

$shop_id = tenantShopId();
$user_id = (int)($_SESSION['user_id'] ?? ($_SESSION['id'] ?? 0));
$user_name = $_SESSION['user_name'] ?? ($_SESSION['name'] ?? 'Admin');

// ============================================================
// HELPERS
// ============================================================
function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function taka($amount, $decimals = 2) {
    return 'TK. ' . number_format((float)$amount, $decimals);
}

function safeIdentifier($name) {
    return preg_match('/^[a-zA-Z0-9_]+$/', (string)$name) ? $name : '';
}

function tableExists($conn, $table) {
    static $cache = [];
    $table = safeIdentifier($table);
    if ($table === '') return false;
    if (isset($cache[$table])) return $cache[$table];

    try {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1");
        if (!$stmt) {
            error_log('tableExists prepare failed: ' . $conn->error);
            return false;
        }
        $stmt->bind_param('s', $table);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_row() : [0];
        $cache[$table] = ((int)($row[0] ?? 0) > 0);
        return $cache[$table];
    } catch (Exception $e) {
        error_log('tableExists error: ' . $e->getMessage());
        return false;
    }
}

function columnExists($conn, $table, $column) {
    static $cache = [];
    $table = safeIdentifier($table);
    $column = safeIdentifier($column);
    if ($table === '' || $column === '') return false;
    $key = $table . '.' . $column;
    if (isset($cache[$key])) return $cache[$key];

    try {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
        if (!$stmt) {
            error_log('columnExists prepare failed: ' . $conn->error);
            return false;
        }
        $stmt->bind_param('ss', $table, $column);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_row() : [0];
        $cache[$key] = ((int)($row[0] ?? 0) > 0);
        return $cache[$key];
    } catch (Exception $e) {
        error_log('columnExists error: ' . $e->getMessage());
        return false;
    }
}

function scalarQuery($conn, $sql, $types = '', $params = []) {
    try {
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            error_log('scalarQuery prepare failed: ' . $conn->error . ' SQL: ' . $sql);
            return 0;
        }
        if ($types !== '' && !empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        if (!$res) return 0;
        $row = $res->fetch_row();
        return $row ? ($row[0] ?? 0) : 0;
    } catch (Exception $e) {
        error_log('scalarQuery error: ' . $e->getMessage());
        return 0;
    }
}

function fetchRows($conn, $sql, $types = '', $params = []) {
    try {
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            error_log('fetchRows prepare failed: ' . $conn->error . ' SQL: ' . $sql);
            return [];
        }
        if ($types !== '' && !empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        if (!$res) return [];
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    } catch (Exception $e) {
        error_log('fetchRows error: ' . $e->getMessage());
        return [];
    }
}

function postValue($key, $default = '') {
    return isset($_POST[$key]) ? trim((string)$_POST[$key]) : $default;
}

function cleanText($value, $maxLength = 255) {
    $value = trim((string)$value);
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value);
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        if (mb_strlen($value, 'UTF-8') > $maxLength) {
            $value = mb_substr($value, 0, $maxLength, 'UTF-8');
        }
    } elseif (strlen($value) > $maxLength) {
        $value = substr($value, 0, $maxLength);
    }
    return $value;
}

function setFlash($type, $message) {
    $_SESSION['supplier_flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    $flash = $_SESSION['supplier_flash'] ?? null;
    unset($_SESSION['supplier_flash']);
    return $flash;
}

function csrfToken() {
    if (empty($_SESSION['supplier_csrf_token'])) {
        $_SESSION['supplier_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['supplier_csrf_token'];
}

function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . h(csrfToken()) . '">';
}

function csrfIsValid() {
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    return is_string($token)
        && $token !== ''
        && !empty($_SESSION['supplier_csrf_token'])
        && hash_equals($_SESSION['supplier_csrf_token'], $token);
}

function redirectToSelf($params = []) {
    $base = basename($_SERVER['PHP_SELF']);
    if (!empty($params)) $base .= '?' . http_build_query($params);
    header('Location: ' . $base);
    exit;
}

function paymentAssetTypes() {
    return [
        'cash' => 'নগদ / Cash',
        'bkash' => 'বিকাশ / bKash',
        'nagad' => 'নগদ মোবাইল ব্যাংকিং / Nagad',
        'bank' => 'ব্যাংক / Bank',
        'other' => 'Other'
    ];
}

function typeLabel($type, $labels) {
    return $labels[$type] ?? ucfirst(str_replace('_', ' ', (string)$type));
}

function statusBadgeClass($status) {
    return ((int)$status === 1) ? 'v3-badge-green' : 'v3-badge-gray';
}

function supplierCode($name) {
    $clean = strtoupper(preg_replace('/[^A-Z0-9]/', '', substr((string)$name, 0, 6)));
    if ($clean === '') $clean = 'SUP';
    return 'SUP' . date('YmdHis') . '-' . substr($clean, 0, 3) . random_int(100, 999);
}

function jsonResponse($payload) {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    $json = json_encode($payload);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $payload = [
            'status' => 'error',
            'message' => 'JSON encoding failed: ' . json_last_error_msg()
        ];
        $json = json_encode($payload);
    }
    echo $json;
    exit;
}

$payment_asset_labels = paymentAssetTypes();

$suppliers_table_ready = isset($conn) && $conn && tableExists($conn, 'suppliers');
$supplier_payments_table_ready = isset($conn) && $conn && tableExists($conn, 'supplier_payments');
$purchases_table_ready = isset($conn) && $conn && tableExists($conn, 'purchases');
$assets_table_ready = isset($conn) && $conn && tableExists($conn, 'assets');
$asset_transactions_table_ready = isset($conn) && $conn && tableExists($conn, 'asset_transactions');
$payments_table_ready = isset($conn) && $conn && tableExists($conn, 'payments');

// ============================================================
// AJAX LEDGER - FIXED
// ============================================================
if (isset($_GET['ajax_ledger'])) {
    // Set error handlers for JSON response
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        jsonResponse([
            'status' => 'error',
            'message' => "Error: $errstr in $errfile on line $errline"
        ]);
    });
    set_exception_handler(function($e) {
        jsonResponse([
            'status' => 'error',
            'message' => 'Exception: ' . $e->getMessage()
        ]);
    });

    try {
        if (!$suppliers_table_ready) {
            jsonResponse(['status' => 'error', 'message' => 'Suppliers table not found.']);
        }

        if (!csrfIsValid()) {
            jsonResponse(['status' => 'error', 'message' => 'Invalid security token.']);
        }

        $supplier_id = (int)($_GET['supplier_id'] ?? 0);
        if ($supplier_id <= 0) {
            jsonResponse(['status' => 'error', 'message' => 'Invalid supplier ID.']);
        }

        // Get supplier details
        $supplier_rows = fetchRows(
            $conn,
            "SELECT * FROM suppliers WHERE id = ? AND shop_id = ? LIMIT 1",
            'ii',
            [$supplier_id, $shop_id]
        );
        
        if (empty($supplier_rows)) {
            jsonResponse(['status' => 'error', 'message' => 'Supplier not found.']);
        }
        
        $supplier = $supplier_rows[0];
        
        // Build ledger
        $ledger = [];
        $running = 0.0;
        
        // Opening due
        $opening_due = (float)($supplier['opening_due'] ?? 0);
        if ($opening_due > 0) {
            $running += $opening_due;
            $ledger[] = [
                'date' => (string)($supplier['created_at'] ?? date('Y-m-d H:i:s')),
                'type' => 'Opening Due',
                'reference' => (string)($supplier['supplier_code'] ?? ''),
                'debit' => 0,
                'credit' => $opening_due,
                'balance' => $running,
                'note' => 'Opening payable balance'
            ];
        }

        // Purchase dues
        if ($purchases_table_ready) {
            $purchase_rows = fetchRows(
                $conn,
                "SELECT id, invoice_no, grand_total, paid_amount, due_amount, created_at
                 FROM purchases 
                 WHERE supplier_id = ? 
                 ORDER BY created_at ASC, id ASC",
                'i',
                [$supplier_id]
            );
            
            foreach ($purchase_rows as $p) {
                $due = (float)($p['due_amount'] ?? 0);
                if ($due > 0) {
                    $running += $due;
                    $ledger[] = [
                        'date' => (string)($p['created_at'] ?? date('Y-m-d H:i:s')),
                        'type' => 'Purchase Due',
                        'reference' => 'Purchase #' . (int)$p['id'] . (!empty($p['invoice_no']) ? ' / Inv: ' . $p['invoice_no'] : ''),
                        'debit' => 0,
                        'credit' => $due,
                        'balance' => $running,
                        'note' => 'Grand: ' . taka($p['grand_total'] ?? 0) . ', Paid: ' . taka($p['paid_amount'] ?? 0)
                    ];
                }
            }
        }

        // Supplier payments
        if ($supplier_payments_table_ready) {
            $payment_rows = fetchRows(
                $conn,
                "SELECT id, purchase_id, payment_amount, payment_method, note, payment_date
                 FROM supplier_payments
                 WHERE supplier_id = ?
                 ORDER BY payment_date ASC, id ASC",
                'i',
                [$supplier_id]
            );
            
            foreach ($payment_rows as $pay) {
                $amount = (float)($pay['payment_amount'] ?? 0);
                $running -= $amount;
                $ledger[] = [
                    'date' => (string)($pay['payment_date'] ?? date('Y-m-d H:i:s')),
                    'type' => 'Payment',
                    'reference' => 'Payment #' . (int)$pay['id'] . (!empty($pay['purchase_id']) ? ' / Purchase #' . (int)$pay['purchase_id'] : ''),
                    'debit' => $amount,
                    'credit' => 0,
                    'balance' => $running,
                    'note' => 'Method: ' . (string)($pay['payment_method'] ?? '-') . (!empty($pay['note']) ? ' | ' . $pay['note'] : '')
                ];
            }
        }

        // Sort by date
        usort($ledger, function($a, $b) {
            return strtotime($a['date'] ?: '1970-01-01') <=> strtotime($b['date'] ?: '1970-01-01');
        });

        // Recalculate running balance
        $running = 0.0;
        foreach ($ledger as $i => $row) {
            $running += (float)$row['credit'];
            $running -= (float)$row['debit'];
            $ledger[$i]['balance'] = $running;
        }

        // Success response
        jsonResponse([
            'status' => 'success',
            'supplier' => [
                'id' => (int)$supplier['id'],
                'name' => (string)$supplier['supplier_name'],
                'code' => (string)($supplier['supplier_code'] ?? ''),
                'phone' => (string)($supplier['phone'] ?? ''),
                'current_due' => (float)($supplier['current_due'] ?? 0),
            ],
            'rows' => $ledger
        ]);

    } catch (Exception $e) {
        jsonResponse([
            'status' => 'error',
            'message' => 'Error: ' . $e->getMessage()
        ]);
    }
    
    // Restore error handlers
    restore_error_handler();
    restore_exception_handler();
}

// ============================================================
// POST ACTIONS
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfIsValid()) {
        setFlash('error', 'Security token mismatch. Please try again.');
        redirectToSelf();
    }
    if (!isset($conn) || !$conn) {
        setFlash('error', 'Database connection not available.');
        redirectToSelf();
    }

    $action = postValue('action');

    try {
        if (!$suppliers_table_ready) {
            throw new Exception('Suppliers table not found.');
        }

        // ---------------- ADD / UPDATE SUPPLIER ----------------
        if ($action === 'save_supplier') {
            $supplier_id = (int)postValue('supplier_id', '0');
            $supplier_name = cleanText(postValue('supplier_name'), 150);
            $phone = cleanText(postValue('phone'), 30);
            $email = cleanText(postValue('email'), 100);
            $address = cleanText(postValue('address'), 1000);
            $sr_id_raw = postValue('sr_id', '');
            $sr_id = $sr_id_raw !== '' ? (int)$sr_id_raw : null;
            if ($sr_id !== null && $sr_id > 0) {
                $srRows = fetchRows($conn, "SELECT id FROM sales_representatives WHERE id = ? AND shop_id = ? AND status = 1 LIMIT 1", 'ii', [$sr_id, $shop_id]);
                if (empty($srRows)) {
                    throw new Exception('Selected SR does not belong to this shop.');
                }
            } else {
                $sr_id = null;
            }
            $opening_due_raw = postValue('opening_due', '0');
            $current_due_raw = postValue('current_due', '0');
            $status = (int)postValue('status', '1');
            $status = $status === 1 ? 1 : 0;

            if ($supplier_name === '') throw new Exception('Supplier name is required.');
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new Exception('Invalid email address.');
            if (!is_numeric($opening_due_raw)) throw new Exception('Opening due must be numeric.');
            if (!is_numeric($current_due_raw)) throw new Exception('Current due must be numeric.');
            $opening_due = round((float)$opening_due_raw, 2);
            $current_due = round((float)$current_due_raw, 2);
            if ($opening_due < 0 || $current_due < 0) throw new Exception('Due amount cannot be negative.');

            if ($supplier_id > 0) {
                $dup = fetchRows($conn, "SELECT id FROM suppliers WHERE supplier_name = ? AND shop_id = ? AND id <> ? LIMIT 1", 'sii', [$supplier_name, $shop_id, $supplier_id]);
                if (!empty($dup)) throw new Exception('Supplier name already exists.');

                $stmt = $conn->prepare("UPDATE suppliers
                    SET supplier_name = ?, phone = ?, email = ?, address = ?, sr_id = ?, opening_due = ?, current_due = ?, status = ?
                    WHERE id = ? AND shop_id = ? LIMIT 1");
                if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                $stmt->bind_param('ssssiddiii', $supplier_name, $phone, $email, $address, $sr_id, $opening_due, $current_due, $status, $supplier_id, $shop_id);
                $stmt->execute();
                setFlash('success', 'Supplier updated successfully.');
            } else {
                $dup = fetchRows($conn, "SELECT id FROM suppliers WHERE supplier_name = ? AND shop_id = ? LIMIT 1", 'si', [$supplier_name, $shop_id]);
                if (!empty($dup)) throw new Exception('Supplier name already exists.');

                $code = supplierCode($supplier_name);
                $current_due = $opening_due;
                $stmt = $conn->prepare("INSERT INTO suppliers
                    (shop_id, supplier_code, supplier_name, phone, email, address, sr_id, opening_due, current_due, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                $stmt->bind_param('isssssidd', $shop_id, $code, $supplier_name, $phone, $email, $address, $sr_id, $opening_due, $current_due);
                $stmt->execute();
                setFlash('success', 'Supplier added successfully.');
            }

            redirectToSelf();
        }

        // ---------------- SUPPLIER PAYMENT ----------------
        if ($action === 'pay_supplier') {
            if (!$supplier_payments_table_ready) throw new Exception('Supplier payments table not found.');
            if (!$assets_table_ready) throw new Exception('Assets table not found.');

            $supplier_id = (int)postValue('supplier_id', '0');
            $pay_from_asset_id = (int)postValue('pay_from_asset_id', '0');
            $paid_amount_raw = postValue('paid_amount', '0');
            $payment_date = postValue('payment_date', date('Y-m-d'));
            $payment_note = cleanText(postValue('payment_note'), 2000);

            if ($supplier_id <= 0) throw new Exception('Invalid supplier selected.');
            if ($pay_from_asset_id <= 0) throw new Exception('Please select payment source asset.');
            if (!is_numeric($paid_amount_raw)) throw new Exception('Payment amount must be numeric.');
            $paid_amount = round((float)$paid_amount_raw, 2);
            if ($paid_amount <= 0) throw new Exception('Payment amount must be greater than zero.');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $payment_date)) throw new Exception('Invalid payment date.');

            $conn->begin_transaction();
            try {
                $supplier_rows = fetchRows($conn, "SELECT id, supplier_name, current_due, status FROM suppliers WHERE id = ? AND shop_id = ? AND status = 1 LIMIT 1 FOR UPDATE", 'ii', [$supplier_id, $shop_id]);
                $supplier = $supplier_rows[0] ?? null;
                if (!$supplier) throw new Exception('Active supplier not found.');

                $current_due = round((float)($supplier['current_due'] ?? 0), 2);
                if ($current_due <= 0) throw new Exception('This supplier has no payable due.');
                if ($paid_amount > $current_due) throw new Exception('Payment amount cannot exceed supplier due.');

                $asset_rows = fetchRows($conn, "SELECT id, asset_type, asset_name, amount FROM assets WHERE id = ? AND shop_id = ? AND status = 'active' LIMIT 1 FOR UPDATE", 'ii', [$pay_from_asset_id, $shop_id]);
                $asset = $asset_rows[0] ?? null;
                if (!$asset) throw new Exception('Active payment source asset not found.');

                $asset_type = (string)($asset['asset_type'] ?? 'other');
                if (!array_key_exists($asset_type, paymentAssetTypes())) {
                    throw new Exception('This asset type does not support supplier payment.');
                }

                $asset_before = round((float)($asset['amount'] ?? 0), 2);
                if ($paid_amount > $asset_before) {
                    throw new Exception('Insufficient asset balance. Available: ' . taka($asset_before));
                }

                $asset_after = round($asset_before - $paid_amount, 2);
                $new_due = round($current_due - $paid_amount, 2);

                $stmt = $conn->prepare("UPDATE assets SET amount = ? WHERE id = ? AND shop_id = ? LIMIT 1");
                if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                $stmt->bind_param('dii', $asset_after, $pay_from_asset_id, $shop_id);
                $stmt->execute();

                $stmt = $conn->prepare("UPDATE suppliers SET current_due = ? WHERE id = ? AND shop_id = ? LIMIT 1");
                if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                $stmt->bind_param('dii', $new_due, $supplier_id, $shop_id);
                $stmt->execute();

                $purchase_id = null;
                $payment_method = $asset_type;
                $payment_datetime = $payment_date . ' 00:00:00';
                $stmt = $conn->prepare("INSERT INTO supplier_payments (supplier_id, purchase_id, payment_amount, payment_method, note, payment_date) VALUES (?, ?, ?, ?, ?, ?)");
                if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                $stmt->bind_param('iidsss', $supplier_id, $purchase_id, $paid_amount, $payment_method, $payment_note, $payment_datetime);
                $stmt->execute();

                if ($payments_table_ready) {
                    $type = 'supplier_payment';
                    $stmt = $conn->prepare("INSERT INTO payments (supplier_id, amount, type, note, created_by) VALUES (?, ?, ?, ?, ?)");
                    if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                    $stmt->bind_param('idssi', $supplier_id, $paid_amount, $type, $payment_note, $user_id);
                    $stmt->execute();
                }

                if ($asset_transactions_table_ready) {
                    $from_name = (string)($asset['asset_name'] ?? '');
                    $tx_note = $payment_note !== '' ? $payment_note : ('Supplier payment: ' . (string)$supplier['supplier_name']);
                    $stmt = $conn->prepare("INSERT INTO asset_transactions
                        (shop_id, transaction_type, movement_type,
                         from_asset_id, from_asset_type, from_asset_name,
                         to_asset_id, to_asset_type, to_asset_name,
                         amount, from_balance_before, from_balance_after,
                         to_balance_before, to_balance_after,
                         reference_type, reference_id, transaction_date, note, created_by)
                        VALUES
                        (?, 'out', 'supplier_payment',
                         ?, ?, ?,
                         NULL, NULL, NULL,
                         ?, ?, ?,
                         NULL, NULL,
                         'supplier', ?, ?, ?, ?)");
                    if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
                    $stmt->bind_param('iissdddissi', $shop_id, $pay_from_asset_id, $asset_type, $from_name, $paid_amount, $asset_before, $asset_after, $supplier_id, $payment_date, $tx_note, $user_id);
                    $stmt->execute();
                }

                $conn->commit();
                setFlash('success', 'Supplier payment saved successfully.');
                redirectToSelf();
            } catch (Throwable $e) {
                $conn->rollback();
                throw $e;
            }
        }

        // ---------------- SOFT DELETE SUPPLIER ----------------
        if ($action === 'delete_supplier') {
            $supplier_id = (int)postValue('supplier_id', '0');
            if ($supplier_id <= 0) throw new Exception('Invalid supplier selected.');

            $stmt = $conn->prepare("UPDATE suppliers SET status = 0 WHERE id = ? AND shop_id = ? LIMIT 1");
            if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
            $stmt->bind_param('ii', $supplier_id, $shop_id);
            $stmt->execute();
            setFlash('success', 'Supplier deactivated successfully.');
            redirectToSelf();
        }

        throw new Exception('Invalid action.');
    } catch (Throwable $e) {
        error_log('supplier_management error: ' . $e->getMessage());
        setFlash('error', $e->getMessage());
        redirectToSelf();
    }
}

// ============================================================
// LOAD DATA
// ============================================================
$flash = getFlash();
$search = cleanText($_GET['q'] ?? '', 100);
$status_filter = isset($_GET['status']) ? (string)$_GET['status'] : '1';

$where = "s.shop_id = ?";
$types = 'i';
$params = [$shop_id];

if ($status_filter === '1' || $status_filter === '0') {
    $where .= " AND s.status = ?";
    $types .= 'i';
    $params[] = (int)$status_filter;
}

if ($search !== '') {
    $where .= " AND (s.supplier_name LIKE ? OR s.supplier_code LIKE ? OR s.phone LIKE ? OR s.email LIKE ? OR s.address LIKE ?)";
    $like = '%' . $search . '%';
    $types .= 'sssss';
    array_push($params, $like, $like, $like, $like, $like);
}

$suppliers = [];
if ($suppliers_table_ready) {
    $suppliers = fetchRows(
        $conn,
        "SELECT s.*, sr.sr_name
         FROM suppliers s
         LEFT JOIN sales_representatives sr ON sr.id = s.sr_id AND sr.shop_id = s.shop_id
         WHERE $where
         ORDER BY s.status DESC, s.current_due DESC, s.supplier_name ASC",
        $types,
        $params
    );
}

$sr_list = [];
if (tableExists($conn, 'sales_representatives')) {
    $sr_list = fetchRows($conn, "SELECT id, sr_name FROM sales_representatives WHERE shop_id = ? AND status = 1 ORDER BY sr_name ASC", 'i', [$shop_id]);
}

$payment_assets = [];
if ($assets_table_ready) {
    $payment_assets = fetchRows(
        $conn,
        "SELECT id, asset_type, asset_name, amount
         FROM assets
         WHERE shop_id = ?
           AND status = 'active'
           AND amount > 0
           AND asset_type IN ('cash','bkash','nagad','bank','other')
         ORDER BY FIELD(asset_type, 'cash','bkash','nagad','bank','other'), asset_name ASC",
        'i',
        [$shop_id]
    );
}

$total_suppliers = (int)scalarQuery($conn, "SELECT COUNT(*) FROM suppliers WHERE shop_id = ? AND status = 1", 'i', [$shop_id]);
$total_due = (float)scalarQuery($conn, "SELECT COALESCE(SUM(current_due),0) FROM suppliers WHERE shop_id = ? AND status = 1", 'i', [$shop_id]);
$total_opening_due = (float)scalarQuery($conn, "SELECT COALESCE(SUM(opening_due),0) FROM suppliers WHERE shop_id = ? AND status = 1", 'i', [$shop_id]);
$total_paid_supplier = $supplier_payments_table_ready
    ? (float)scalarQuery($conn, "SELECT COALESCE(SUM(sp.payment_amount),0) FROM supplier_payments sp INNER JOIN suppliers s ON s.id = sp.supplier_id WHERE s.shop_id = ?", 'i', [$shop_id])
    : 0;

include "./../header.php";
include "./../sidebar.php";
?>

<style>
.v3-main{flex:1;padding:24px;background:#f0f4f8;min-height:100vh;font-family:'Segoe UI',system-ui,sans-serif}.v3-header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;margin-bottom:20px;background:#fff;padding:22px 28px;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e2e8f0}.v3-header-text h4{font-size:1.5rem;font-weight:800;margin:0 0 6px;color:#1e293b}.v3-header-text h4 i{color:#10b981;margin-right:8px}.v3-header-text p{color:#64748b;margin:0;font-size:.85rem}.v3-btn{border:none;border-radius:12px;padding:10px 16px;font-size:.85rem;font-weight:800;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:8px;transition:all .2s ease}.v3-btn:hover{transform:translateY(-1px)}.v3-btn-primary{background:#2563eb;color:#fff}.v3-btn-success{background:#059669;color:#fff}.v3-btn-danger{background:#dc2626;color:#fff}.v3-btn-light{background:#f1f5f9;color:#334155}.v3-btn-warning{background:#f59e0b;color:#fff}.v3-btn-purple{background:#7c3aed;color:#fff}.v3-btn-sm{padding:7px 10px;font-size:.78rem;border-radius:10px}.v3-alert{padding:12px 16px;border-radius:12px;margin-bottom:16px;font-size:.9rem;border:1px solid transparent}.v3-alert-success{background:#ecfdf5;color:#047857;border-color:#bbf7d0}.v3-alert-error{background:#fef2f2;color:#b91c1c;border-color:#fecaca}.v3-warning-box{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:12px;padding:12px 16px;margin-bottom:16px;font-size:.9rem}.v3-summary-row{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:20px}.v3-summary-card{background:#fff;padding:20px;border-radius:14px;box-shadow:0 1px 6px rgba(0,0,0,.04);border:1px solid #e2e8f0;position:relative;overflow:hidden}.v3-summary-card:before{content:'';position:absolute;left:0;top:0;bottom:0;width:5px;background:#10b981}.v3-summary-card h6{margin:0 0 10px;font-size:.8rem;color:#64748b;font-weight:800;text-transform:uppercase;letter-spacing:.6px}.v3-summary-big{display:block;font-size:1.55rem;font-weight:900;color:#1e293b;line-height:1.2;margin-bottom:6px}.v3-summary-sub{font-size:.8rem;color:#64748b}.v3-panel{background:#fff;padding:22px;border-radius:18px;box-shadow:0 1px 8px rgba(0,0,0,.04);border:1px solid #e2e8f0;margin-bottom:20px}.v3-panel-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap}.v3-panel h5{margin:0;font-size:1rem;font-weight:900;color:#1e293b;display:flex;align-items:center;gap:8px}.v3-filter-form{display:flex;gap:10px;flex-wrap:wrap}.v3-filter-form input,.v3-filter-form select{border:1px solid #cbd5e1;border-radius:12px;padding:9px 12px;font-size:.9rem;outline:none}.v3-table-wrap{overflow-x:auto;border:1px solid #e2e8f0;border-radius:14px}.v3-table{width:100%;border-collapse:collapse;min-width:1050px;background:#fff}.v3-table th,.v3-table td{padding:12px 14px;border-bottom:1px solid #f1f5f9;text-align:left;font-size:.86rem;vertical-align:top}.v3-table th{background:#f8fafc;color:#334155;font-weight:900;white-space:nowrap}.v3-table td{color:#475569}.v3-table tr:last-child td{border-bottom:none}.v3-money{font-weight:900;color:#1e293b;font-family:'Courier New',monospace;white-space:nowrap}.v3-badge{display:inline-flex;padding:4px 10px;border-radius:999px;font-size:.72rem;font-weight:900;white-space:nowrap}.v3-badge-green{background:#dcfce7;color:#166534}.v3-badge-gray{background:#f1f5f9;color:#475569}.v3-muted{color:#94a3b8;font-size:.8rem}.v3-inline-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.v3-empty{padding:22px;text-align:center;color:#64748b}.v3-modal-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;padding:18px;z-index:9999}.v3-modal-backdrop.v3-modal-show{display:flex}.v3-modal-card{width:100%;max-width:720px;max-height:92vh;overflow:hidden;background:#fff;border-radius:18px;box-shadow:0 24px 70px rgba(0,0,0,.25);border:1px solid #e2e8f0;display:flex;flex-direction:column}.v3-modal-card.v3-modal-lg{max-width:960px}.v3-modal-head{display:flex;justify-content:space-between;align-items:center;padding:18px 20px;background:#f8fafc;border-bottom:1px solid #e2e8f0}.v3-modal-head h5{margin:0;font-size:1rem;font-weight:900;color:#1e293b}.v3-modal-close{width:34px;height:34px;border:none;border-radius:10px;background:#e2e8f0;color:#334155;cursor:pointer;font-weight:900}.v3-modal-body{padding:20px;overflow:auto}.v3-form-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.v3-field-full{grid-column:1/-1}.v3-field label{display:block;font-size:.78rem;color:#475569;font-weight:800;margin-bottom:6px}.v3-field input,.v3-field select,.v3-field textarea{width:100%;border:1px solid #cbd5e1;border-radius:12px;padding:10px 12px;font-size:.9rem;color:#1e293b;background:#fff;outline:none;transition:all .2s ease}.v3-field textarea{min-height:82px;resize:vertical}.v3-field input:focus,.v3-field select:focus,.v3-field textarea:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.12)}.v3-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:16px;flex-wrap:wrap}.v3-pay-context{background:#f8fafc;border:1px dashed #cbd5e1;border-radius:12px;padding:12px 14px;margin-bottom:14px;color:#334155;font-size:.9rem}.ledger-table{width:100%;border-collapse:collapse;min-width:820px}.ledger-table th,.ledger-table td{padding:10px;border-bottom:1px solid #e2e8f0;font-size:.84rem;text-align:left}.ledger-table th{background:#f8fafc;color:#334155;font-weight:900}@media(max-width:1200px){.v3-summary-row{grid-template-columns:repeat(2,1fr)}}@media(max-width:767px){.v3-main{padding:14px}.v3-header{padding:16px 20px}.v3-summary-row,.v3-form-grid{grid-template-columns:1fr}.v3-filter-form{width:100%}.v3-filter-form input,.v3-filter-form select,.v3-filter-form .v3-btn{width:100%}.v3-btn{width:100%}.v3-actions{justify-content:stretch}}
</style>

<div class="v3-main">
    <div class="v3-header">
        <div class="v3-header-text">
            <h4><i class="fas fa-truck"></i> Supplier Management</h4>
            <p><?= h(date('l, d F Y')) ?> · Supplier CRUD, payment and ledger · Shop ID: <?= (int)$shop_id ?></p>
        </div>
        <button class="v3-btn v3-btn-success" type="button" data-open-supplier-modal data-mode="add"><i class="fas fa-plus"></i> Add Supplier</button>
    </div>

    <?php if ($flash): ?>
        <div class="v3-alert <?= ($flash['type'] ?? '') === 'success' ? 'v3-alert-success' : 'v3-alert-error' ?>"><?= h($flash['message'] ?? '') ?></div>
    <?php endif; ?>

    <?php if (!$suppliers_table_ready): ?>
        <div class="v3-warning-box"><strong>Table missing:</strong> `suppliers` table পাওয়া যায়নি।</div>
    <?php endif; ?>
    <?php if ($suppliers_table_ready && !$supplier_payments_table_ready): ?>
        <div class="v3-warning-box"><strong>Payment table missing:</strong> `supplier_payments` table পাওয়া যায়নি। Payment disabled থাকবে।</div>
    <?php endif; ?>
    <?php if ($suppliers_table_ready && (!$assets_table_ready || !$asset_transactions_table_ready)): ?>
        <div class="v3-warning-box"><strong>Asset connection warning:</strong> `assets` বা `asset_transactions` table পাওয়া যায়নি। Supplier payment করলে asset balance/history update করা যাবে না।</div>
    <?php endif; ?>

    <div class="v3-summary-row">
        <div class="v3-summary-card"><h6>Active Suppliers</h6><span class="v3-summary-big"><?= number_format($total_suppliers) ?></span><span class="v3-summary-sub">Status active only</span></div>
        <div class="v3-summary-card"><h6>Total Current Due</h6><span class="v3-summary-big"><?= taka($total_due) ?></span><span class="v3-summary-sub">Payable to suppliers</span></div>
        <div class="v3-summary-card"><h6>Opening Due</h6><span class="v3-summary-big"><?= taka($total_opening_due) ?></span><span class="v3-summary-sub">Initial supplier due</span></div>
        <div class="v3-summary-card"><h6>Total Paid</h6><span class="v3-summary-big"><?= taka($total_paid_supplier) ?></span><span class="v3-summary-sub">supplier_payments history</span></div>
    </div>

    <div class="v3-panel">
        <div class="v3-panel-head">
            <h5><i class="fas fa-list"></i> Suppliers</h5>
            <form class="v3-filter-form" method="get">
                <input type="text" name="q" value="<?= h($search) ?>" placeholder="Search supplier, phone, code">
                <select name="status">
                    <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>All</option>
                    <option value="1" <?= $status_filter === '1' ? 'selected' : '' ?>>Active</option>
                    <option value="0" <?= $status_filter === '0' ? 'selected' : '' ?>>Inactive</option>
                </select>
                <button class="v3-btn v3-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                <a class="v3-btn v3-btn-light" href="<?= h(basename($_SERVER['PHP_SELF'])) ?>"><i class="fas fa-rotate-left"></i> Reset</a>
            </form>
        </div>
        <div class="v3-table-wrap">
            <table class="v3-table">
                <thead>
                    <tr>
                        <th>Code</th><th>Supplier</th><th>Contact</th><th>SR</th><th>Opening Due</th><th>Current Due</th><th>Status</th><th>Created</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!empty($suppliers)): ?>
                    <?php foreach ($suppliers as $s): ?>
                        <tr>
                            <td><strong><?= h($s['supplier_code'] ?? '') ?></strong></td>
                            <td><strong><?= h($s['supplier_name'] ?? '') ?></strong><div class="v3-muted"><?= h($s['address'] ?? '') ?></div></td>
                            <td><?= h($s['phone'] ?? '') ?><div class="v3-muted"><?= h($s['email'] ?? '') ?></div></td>
                            <td><?= h($s['sr_name'] ?? '-') ?></td>
                            <td class="v3-money"><?= taka($s['opening_due'] ?? 0) ?></td>
                            <td class="v3-money"><?= taka($s['current_due'] ?? 0) ?></td>
                            <td><span class="v3-badge <?= h(statusBadgeClass($s['status'] ?? 0)) ?>"><?= ((int)($s['status'] ?? 0) === 1) ? 'Active' : 'Inactive' ?></span></td>
                            <td class="v3-muted"><?= h($s['created_at'] ?? '') ?></td>
                            <td>
                                <div class="v3-inline-actions">
                                    <button class="v3-btn v3-btn-warning v3-btn-sm" type="button"
                                        data-open-supplier-modal data-mode="edit"
                                        data-id="<?= (int)$s['id'] ?>"
                                        data-name="<?= h($s['supplier_name'] ?? '') ?>"
                                        data-phone="<?= h($s['phone'] ?? '') ?>"
                                        data-email="<?= h($s['email'] ?? '') ?>"
                                        data-address="<?= h($s['address'] ?? '') ?>"
                                        data-sr="<?= h((string)($s['sr_id'] ?? '')) ?>"
                                        data-opening="<?= h((string)($s['opening_due'] ?? '0')) ?>"
                                        data-current="<?= h((string)($s['current_due'] ?? '0')) ?>"
                                        data-status="<?= (int)($s['status'] ?? 0) ?>"><i class="fas fa-edit"></i> Edit</button>

                                    <?php if ((int)($s['status'] ?? 0) === 1 && (float)($s['current_due'] ?? 0) > 0): ?>
                                        <button class="v3-btn v3-btn-success v3-btn-sm" type="button"
                                            data-open-pay-modal
                                            data-id="<?= (int)$s['id'] ?>"
                                            data-name="<?= h($s['supplier_name'] ?? '') ?>"
                                            data-due="<?= h((string)($s['current_due'] ?? '0')) ?>"
                                            <?= (!$supplier_payments_table_ready || !$assets_table_ready || empty($payment_assets)) ? 'disabled' : '' ?>><i class="fas fa-money-bill-transfer"></i> Pay</button>
                                    <?php endif; ?>

                                    <button class="v3-btn v3-btn-purple v3-btn-sm" type="button" data-open-ledger data-id="<?= (int)$s['id'] ?>"><i class="fas fa-book"></i> Ledger</button>

                                    <?php if ((int)($s['status'] ?? 0) === 1): ?>
                                        <form method="post" onsubmit="return confirm('এই supplier inactive করতে চাও? Data permanently delete হবে না।');">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="delete_supplier">
                                            <input type="hidden" name="supplier_id" value="<?= (int)$s['id'] ?>">
                                            <button class="v3-btn v3-btn-danger v3-btn-sm" type="submit"><i class="fas fa-ban"></i> Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="9"><div class="v3-empty">No supplier found.</div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Supplier Add/Edit Modal -->
    <div class="v3-modal-backdrop" id="supplierModal" aria-hidden="true">
        <div class="v3-modal-card" role="dialog" aria-modal="true">
            <div class="v3-modal-head">
                <h5 id="supplierModalTitle"><i class="fas fa-truck"></i> Add Supplier</h5>
                <button class="v3-modal-close" type="button" data-close-supplier>&times;</button>
            </div>
            <div class="v3-modal-body">
                <form method="post" autocomplete="off" id="supplierForm">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="save_supplier">
                    <input type="hidden" name="supplier_id" id="supplierId" value="0">
                    <div class="v3-form-grid">
                        <div class="v3-field v3-field-full"><label>Supplier Name *</label><input type="text" name="supplier_name" id="supplierName" required maxlength="150"></div>
                        <div class="v3-field"><label>Phone</label><input type="text" name="phone" id="supplierPhone" maxlength="30"></div>
                        <div class="v3-field"><label>Email</label><input type="email" name="email" id="supplierEmail" maxlength="100"></div>
                        <div class="v3-field v3-field-full"><label>Address</label><textarea name="address" id="supplierAddress" maxlength="1000"></textarea></div>
                        <div class="v3-field"><label>Sales Representative</label><select name="sr_id" id="supplierSr"><option value="">Select SR</option><?php foreach($sr_list as $sr): ?><option value="<?= (int)$sr['id'] ?>"><?= h($sr['sr_name'] ?? '') ?></option><?php endforeach; ?></select></div>
                        <div class="v3-field"><label>Status</label><select name="status" id="supplierStatus"><option value="1">Active</option><option value="0">Inactive</option></select></div>
                        <div class="v3-field"><label>Opening Due</label><input type="number" step="0.01" min="0" name="opening_due" id="supplierOpening" value="0.00"></div>
                        <div class="v3-field"><label>Current Due</label><input type="number" step="0.01" min="0" name="current_due" id="supplierCurrent" value="0.00"><div class="v3-muted">New supplier হলে Opening Due = Current Due হবে।</div></div>
                    </div>
                    <div class="v3-actions"><button class="v3-btn v3-btn-light" type="button" data-close-supplier><i class="fas fa-xmark"></i> Cancel</button><button class="v3-btn v3-btn-success" type="submit"><i class="fas fa-save"></i> Save Supplier</button></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div class="v3-modal-backdrop" id="payModal" aria-hidden="true">
        <div class="v3-modal-card" role="dialog" aria-modal="true">
            <div class="v3-modal-head"><h5><i class="fas fa-money-bill-transfer"></i> Supplier Payment</h5><button class="v3-modal-close" type="button" data-close-pay>&times;</button></div>
            <div class="v3-modal-body">
                <div class="v3-pay-context"><div><strong>Supplier:</strong> <span id="paySupplierName">-</span></div><div><strong>Current Due:</strong> <span id="paySupplierDue">TK. 0.00</span></div></div>
                <?php if (empty($payment_assets)): ?><div class="v3-warning-box">কোন active Cash/bKash/Nagad/Bank asset balance পাওয়া যায়নি। আগে Asset CRUD থেকে balance add/update করো।</div><?php endif; ?>
                <form method="post" autocomplete="off">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="pay_supplier">
                    <input type="hidden" name="supplier_id" id="paySupplierId" value="0">
                    <div class="v3-form-grid">
                        <div class="v3-field v3-field-full"><label>Pay From Asset</label><select name="pay_from_asset_id" required <?= empty($payment_assets) ? 'disabled' : '' ?>><option value="">Select source</option><?php foreach($payment_assets as $asset): ?><option value="<?= (int)$asset['id'] ?>"><?= h(typeLabel($asset['asset_type'] ?? '', $payment_asset_labels)) ?> — <?= h($asset['asset_name'] ?? '') ?> — <?= taka($asset['amount'] ?? 0) ?></option><?php endforeach; ?></select></div>
                        <div class="v3-field"><label>Payment Amount</label><input type="number" name="paid_amount" id="payAmount" min="0.01" step="0.01" required <?= empty($payment_assets) ? 'disabled' : '' ?>></div>
                        <div class="v3-field"><label>Payment Date</label><input type="date" name="payment_date" value="<?= h(date('Y-m-d')) ?>" required <?= empty($payment_assets) ? 'disabled' : '' ?>></div>
                        <div class="v3-field v3-field-full"><label>Note</label><textarea name="payment_note" maxlength="2000" placeholder="Receipt / payment note" <?= empty($payment_assets) ? 'disabled' : '' ?>></textarea></div>
                    </div>
                    <div class="v3-actions"><button class="v3-btn v3-btn-light" type="button" data-close-pay><i class="fas fa-xmark"></i> Cancel</button><button class="v3-btn v3-btn-success" type="submit" <?= empty($payment_assets) ? 'disabled' : '' ?>><i class="fas fa-check"></i> Confirm Payment</button></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Ledger Modal -->
    <div class="v3-modal-backdrop" id="ledgerModal" aria-hidden="true">
        <div class="v3-modal-card v3-modal-lg" role="dialog" aria-modal="true">
            <div class="v3-modal-head"><h5><i class="fas fa-book"></i> Supplier Ledger</h5><button class="v3-modal-close" type="button" data-close-ledger>&times;</button></div>
            <div class="v3-modal-body">
                <div class="v3-pay-context" id="ledgerSummary">Loading...</div>
                <div class="v3-table-wrap"><table class="ledger-table"><thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Payment/Debit</th><th>Due/Credit</th><th>Balance</th><th>Note</th></tr></thead><tbody id="ledgerRows"><tr><td colspan="7">Loading...</td></tr></tbody></table></div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function(){
    const csrf = <?= json_encode(csrfToken()) ?>;
    function fmt(n){ n = Number(n || 0); return 'TK. ' + n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
    function show(el){ if(el){ el.classList.add('v3-modal-show'); el.setAttribute('aria-hidden','false'); } }
    function hide(el){ if(el){ el.classList.remove('v3-modal-show'); el.setAttribute('aria-hidden','true'); } }

    const supplierModal = document.getElementById('supplierModal');
    const supplierTitle = document.getElementById('supplierModalTitle');
    document.querySelectorAll('[data-open-supplier-modal]').forEach(btn => {
        btn.addEventListener('click', function(){
            const mode = btn.getAttribute('data-mode') || 'add';
            document.getElementById('supplierForm').reset();
            document.getElementById('supplierId').value = '0';
            document.getElementById('supplierOpening').value = '0.00';
            document.getElementById('supplierCurrent').value = '0.00';
            document.getElementById('supplierStatus').value = '1';
            supplierTitle.innerHTML = '<i class="fas fa-truck"></i> Add Supplier';
            if(mode === 'edit'){
                supplierTitle.innerHTML = '<i class="fas fa-edit"></i> Edit Supplier';
                document.getElementById('supplierId').value = btn.dataset.id || '0';
                document.getElementById('supplierName').value = btn.dataset.name || '';
                document.getElementById('supplierPhone').value = btn.dataset.phone || '';
                document.getElementById('supplierEmail').value = btn.dataset.email || '';
                document.getElementById('supplierAddress').value = btn.dataset.address || '';
                document.getElementById('supplierSr').value = btn.dataset.sr || '';
                document.getElementById('supplierOpening').value = btn.dataset.opening || '0.00';
                document.getElementById('supplierCurrent').value = btn.dataset.current || '0.00';
                document.getElementById('supplierStatus').value = btn.dataset.status || '1';
            }
            show(supplierModal);
        });
    });
    document.querySelectorAll('[data-close-supplier]').forEach(btn => btn.addEventListener('click', () => hide(supplierModal)));

    const payModal = document.getElementById('payModal');
    document.querySelectorAll('[data-open-pay-modal]').forEach(btn => {
        btn.addEventListener('click', function(){
            const id = btn.dataset.id || '0';
            const name = btn.dataset.name || '-';
            const due = btn.dataset.due || '0';
            document.getElementById('paySupplierId').value = id;
            document.getElementById('paySupplierName').textContent = name;
            document.getElementById('paySupplierDue').textContent = fmt(due);
            document.getElementById('payAmount').value = due;
            document.getElementById('payAmount').max = due;
            show(payModal);
        });
    });
    document.querySelectorAll('[data-close-pay]').forEach(btn => btn.addEventListener('click', () => hide(payModal)));

    const ledgerModal = document.getElementById('ledgerModal');
    const ledgerSummary = document.getElementById('ledgerSummary');
    const ledgerRows = document.getElementById('ledgerRows');
    document.querySelectorAll('[data-open-ledger]').forEach(btn => {
        btn.addEventListener('click', function(){
            const id = btn.dataset.id || '0';
            ledgerSummary.textContent = 'Loading...';
            ledgerRows.innerHTML = '<tr><td colspan="7">Loading...</td></tr>';
            show(ledgerModal);
            
            // Fixed: Proper error handling in fetch
            fetch(`${location.pathname}?ajax_ledger=1&supplier_id=${encodeURIComponent(id)}&csrf_token=${encodeURIComponent(csrf)}`)
                .then(r => {
                    if (!r.ok) {
                        throw new Error(`HTTP error! status: ${r.status}`);
                    }
                    return r.json();
                })
                .then(data => {
                    if (data.status !== 'success') {
                        throw new Error(data.message || 'Ledger load failed');
                    }
                    const s = data.supplier;
                    ledgerSummary.innerHTML = `<strong>${s.name}</strong> ${s.code ? '('+s.code+')' : ''} · Phone: ${s.phone || '-'} · Current Due: <strong>${fmt(s.current_due)}</strong>`;
                    
                    if (!data.rows || data.rows.length === 0) {
                        ledgerRows.innerHTML = '<tr><td colspan="7">No ledger entries found.</td></tr>';
                        return;
                    }
                    
                    ledgerRows.innerHTML = data.rows.map(row => `
                        <tr>
                            <td>${row.date || '-'}</td>
                            <td><strong>${row.type || '-'}</strong></td>
                            <td>${row.reference || '-'}</td>
                            <td class="v3-money">${fmt(row.debit)}</td>
                            <td class="v3-money">${fmt(row.credit)}</td>
                            <td class="v3-money">${fmt(row.balance)}</td>
                            <td>${row.note || ''}</td>
                        </tr>
                    `).join('');
                })
                .catch(err => {
                    console.error('Ledger error:', err);
                    ledgerSummary.textContent = 'Error: ' + err.message;
                    ledgerRows.innerHTML = '<tr><td colspan="7">Failed to load ledger. Please try again.</td></tr>';
                });
        });
    });
    document.querySelectorAll('[data-close-ledger]').forEach(btn => btn.addEventListener('click', () => hide(ledgerModal)));

    // Close modals on backdrop click
    [supplierModal, payModal, ledgerModal].forEach(modal => {
        if(!modal) return;
        modal.addEventListener('click', function(e){ 
            if(e.target === modal) hide(modal); 
        });
    });
    
    // Close modals on ESC key
    document.addEventListener('keydown', function(e){ 
        if(e.key === 'Escape'){
            hide(supplierModal); 
            hide(payModal); 
            hide(ledgerModal); 
        } 
    });
});
</script>

<?php include "./../footer.php"; ?>