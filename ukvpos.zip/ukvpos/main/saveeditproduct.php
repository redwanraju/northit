<?php
// configuration
include('../connect.php');

// new data
$id =$_POST['id'];
$i = $_POST['date_arrival'];
$a = $_POST['product_name'];
//$z = $_POST['gen'];
//$b = $_POST['name'];
//$c = $_POST['exdate'];
$d = $_POST['price'];
$e = $_POST['supplier'];
$f = $_POST['qty'];
$g = $_POST['o_price'];
//$h = $_POST['profit'];
//$j = $_POST['qty_sold'];
// query
$sql = "UPDATE products SET product_id=? id,date_arrival=?, product_name=?, price=?, supplier=?, qty=?, o_price,=? WHERE product_id=?";
$q = $db->prepare($sql);
$q->execute(array($id,$i,$a,$d,$e,$f,$g,));
header("location: products.php");

?>