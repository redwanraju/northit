<?php
session_start();
include('../connect.php');
$a = $_POST['categoryname'];


// query
$sql = "INSERT INTO category (categoryname) VALUES (:a)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a));
header("location: category.php");


?>