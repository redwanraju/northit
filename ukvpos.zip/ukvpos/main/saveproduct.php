<?php
session_start();
include('../connect.php');
$a = $_POST['product_name'];
$b = $_POST['categoryname'];

$d = $_POST['price'];
$e = $_POST['supplier'];
$f = $_POST['qty'];
$l = $_POST['kpics'];
$g = $_POST['o_price'];
$h = $_POST['profit'];

$j = $_POST['date_arrival'];
//$k = $_POST['qty_sold']; //total product stock
// query
$sql = "INSERT INTO products (product_name,category,price,supplier,qty,kpics,o_price,profit,date_arrival) VALUES (:a,:b,:d,:e,:f,:l,:g,:h,:j)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':d'=>$d,':e'=>$e,':f'=>$f,':l'=>$l,':g'=>$g,':h'=>$h,':j'=>$j));
header("location: products.php");


?>